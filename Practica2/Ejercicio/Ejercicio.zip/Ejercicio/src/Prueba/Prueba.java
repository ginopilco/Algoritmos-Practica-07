package Prueba;
import InterfacesClasesGenericas.OperacionesMatInteger;
import InterfacesClasesGenericas.OperacionesMatDouble;
import java.util.Scanner;

public class Prueba {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcion;
        System.out.println("Seleccione el tipo de número: ");
        System.out.println("1. Integer");
        System.out.println("2. Double");
        System.out.print("Opción: ");
        int tipo = scanner.nextInt();

        if (tipo != 1 && tipo != 2) {
            System.out.println("Opción no válida.");
            return;
        }

        do {
            System.out.println("Menu de Operaciones:");
            System.out.println("1. Suma");
            System.out.println("2. Resta");
            System.out.println("3. Producto");
            System.out.println("4. División");
            System.out.println("5. Potencia");
            System.out.println("6. Raíz Cuadrada");
            System.out.println("7. Raíz Cúbica");
            System.out.println("8. Salir");
            System.out.print("Seleccione una opcion: ");
            opcion = scanner.nextInt();

            if (opcion >= 1 && opcion <= 7) {
                System.out.print("Ingrese su primer numero: ");
                double num1 = scanner.nextDouble();
                
                double num2 = 0;
                if (opcion != 6 && opcion != 7) { // Raíz cuadrada y cúbica no necesitan segundo número
                    System.out.print("Ingrese su segundo numero: ");
                    num2 = scanner.nextDouble();
                }

                if (tipo == 1) {
                    OperacionesMatInteger operaciones = new OperacionesMatInteger();
                    realizarOperacion(opcion, operaciones, (int) num1, (int) num2);
                } else {
                    OperacionesMatDouble operaciones = new OperacionesMatDouble();
                    realizarOperacion(opcion, operaciones, num1, num2);
                }
            }
        } while (opcion != 8);

        System.out.println("El programa a finalizado.");
        scanner.close();
    }

    private static <N extends Number> void realizarOperacion(int opcion, InterfacesClasesGenericas.Operable<N> operaciones, N num1, N num2) {
        switch (opcion) {
            case 1:
                System.out.println("Resultado: " + operaciones.suma(num1, num2));
                break;
            case 2:
                System.out.println("Resultado: " + operaciones.resta(num1, num2));
                break;
            case 3:
                System.out.println("Resultado: " + operaciones.producto(num1, num2));
                break;
            case 4:
                if (num2.doubleValue() == 0) {
                    System.out.println("No se puede dividir por cero.");
                } else {
                    System.out.println("Resultado: " + operaciones.division(num1, num2));
                }
                break;
            case 5:
                System.out.println("Resultado: " + Math.pow(num1.doubleValue(), num2.doubleValue()));
                break;
            case 6:
                System.out.println("Resultado: " + Math.sqrt(num1.doubleValue()));
                break;
            case 7:
                System.out.println("Resultado: " + Math.cbrt(num1.doubleValue()));
                break;
            default:
                System.out.println("Opcion no valida.");
        }
    }
}
