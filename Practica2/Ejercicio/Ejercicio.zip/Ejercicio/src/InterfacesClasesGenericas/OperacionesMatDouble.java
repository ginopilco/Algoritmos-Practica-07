package InterfacesClasesGenericas;

public class OperacionesMatDouble implements Operable<Double> {
    @Override
    public Double suma(Double operando1, Double operando2) {
        return operando1 + operando2;
    }

    @Override
    public Double resta(Double operando1, Double operando2) {
        return operando1 - operando2;
    }

    @Override
    public Double producto(Double operando1, Double operando2) {
        return operando1 * operando2;
    }

    @Override
    public Double division(Double operando1, Double operando2) {
        if (operando2 == 0.0) {
            throw new ArithmeticException("No se puede dividir por cero.");
        }
        return operando1 / operando2;
    }
}
