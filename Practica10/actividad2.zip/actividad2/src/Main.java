

import java.util.Scanner;

import btree.BTree;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        BTree<Integer> arbol = new BTree<>(5); // orden 4 = B-Tree grado 4
        int opcion;

        do {
            System.out.println("\n menu arbol B ");
            System.out.println("1) insertar");
            System.out.println("2) buscar");
            System.out.println("3) eliminar");
            System.out.println("4) mostrar arbol");
            System.out.println("0) salir");
            System.out.print("Seleccione una de las opcion: ");
            opcion = sc.nextInt();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el numero que quiere insertar: ");
                    int dato = sc.nextInt();
                    arbol.insert(dato);
                    break;
                case 2:
                    System.out.print("Ingrese el numero que quiere buscar: ");
                    int buscar = sc.nextInt();
                    System.out.println(arbol.search(buscar) ? "Encontrado." : "No encontrado.");
                    break;
                case 3:
                    System.out.print("Ingrese el numero que quiere eliminar: ");
                    int eliminar = sc.nextInt();
                    arbol.delete(eliminar);
                    break;
                case 4:
                    System.out.println(" CONTENIDO DEL ÁRBOL B:");
                    System.out.println(arbol);
                    break;
                case 0:
                    System.out.println("Saliendo");
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        } while (opcion != 0);

        sc.close();
    }
}
