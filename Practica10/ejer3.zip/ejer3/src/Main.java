import btree.*;

public class Main {
    public static void main(String[] args) {
        try {
            BTree<Integer> arbol = BTree.buildFromFile("arbol1.txt");
            System.out.println("\nÁrbol construido exitosamente:\n");
            System.out.println(arbol);
        } catch (ItemNotFound e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
