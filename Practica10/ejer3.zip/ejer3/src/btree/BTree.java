package btree;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class BTree<E extends Comparable<E>> {
    private BNode<E> root;
    private int orden;

    public BTree(int orden) {
        this.orden = orden;
        root = null;
    }

    public boolean isEmpty() {
        return root == null;
    }
    //lee archivo
    public static BTree<Integer> buildFromFile(String filePath) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            int orden = Integer.parseInt(br.readLine().trim());
            BTree<Integer> tree = new BTree<>(orden);
            Map<Integer, BNode<Integer>> nodes = new HashMap<>();
            Map<Integer, Integer> levels = new HashMap<>();

            List<String[]> lines = new ArrayList<>();
            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line.trim().split(","));
            }

            // Primero crear todos los nodos
            for (String[] data : lines) {
                int level = Integer.parseInt(data[0]);
                int id = Integer.parseInt(data[1]);
                BNode<Integer> node = new BNode<>(orden);
                node.level = level;
                node.idNode = id;
                for (int i = 2; i < data.length; i++) {
                    node.keys.set(i - 2, Integer.parseInt(data[i]));
                    node.count++;
                }
                nodes.put(id, node);
                levels.put(id, level);
            }

            // Ahora conectar los hijos
            for (Map.Entry<Integer, BNode<Integer>> entry : nodes.entrySet()) {
                int parentId = entry.getKey();
                BNode<Integer> parent = entry.getValue();
                for (Map.Entry<Integer, BNode<Integer>> potentialChild : nodes.entrySet()) {
                    if (levels.get(potentialChild.getKey()) == parent.level + 1) {
                        if (parent.childs.contains(null)) {
                            int index = parent.childs.indexOf(null);
                            parent.childs.set(index, potentialChild.getValue());
                        }
                    }
                }
            }

            // Buscar la raíz (nivel 0)
            for (BNode<Integer> node : nodes.values()) {
                if (node.level == 0) {
                    tree.root = node;
                    break;
                }
            }

            if (!tree.validate(tree.root)) {
                throw new ItemNotFound("El archivo no cumple las propiedades del BTree.");
            }

            return tree;

        } catch (IOException | NumberFormatException e) {
            throw new ItemNotFound("Error al leer el archivo: " + e.getMessage());
        }
    }

    private boolean validate(BNode<E> node) {
        if (node == null) return true;
        if (node.count >= orden || node.count <= 0) return false;
        for (int i = 0; i <= node.count; i++) {
            if (node.childs.get(i) != null) {
                if (!validate(node.childs.get(i))) return false;
            }
        }
        return true;
    }

    public String toString() {
        if (root == null) return "Arbol vacio";
        return writeTree(root);
    }

    private String writeTree(BNode<E> current) {
        if (current == null) return "";
        StringBuilder sb = new StringBuilder();
        sb.append(current.toString()).append("\n");
        for (int i = 0; i <= current.count; i++) {
            sb.append(writeTree(current.childs.get(i)));
        }
        return sb.toString();
    }
}
