package btree;

import java.util.ArrayList;
//lista nodo 
public class BNode<E extends Comparable<E>> {
    public ArrayList<E> keys;
    public ArrayList<BNode<E>> childs;//hijos 
    public int count;
    public int idNode;
    public int level; //niveles

    public BNode(int orden) {
        keys = new ArrayList<>();
        childs = new ArrayList<>();
        for (int i = 0; i < orden; i++) {
            keys.add(null);
            childs.add(null);
        }
        count = 0;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("ID Nodo: ").append(idNode).append(" | Nivel: ").append(level).append(" | Claves: ");
        for (int i = 0; i < count; i++) {
            sb.append(keys.get(i)).append(" ");
        }
        return sb.toString();
    }
}