// Archivo: src/btree/Main.java
package btree;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        BTree<RegistroEstudiante> arbol = new BTree<>(4);

        // Insertar estudiantes iniciales
        arbol.insert(new RegistroEstudiante(103, "Lucía"));
        arbol.insert(new RegistroEstudiante(115, "David"));
        arbol.insert(new RegistroEstudiante(125, "Jorge"));
        arbol.insert(new RegistroEstudiante(140, "Denis"));
        arbol.insert(new RegistroEstudiante(145, "Enrique"));
        arbol.insert(new RegistroEstudiante(122, "Ana"));
        arbol.insert(new RegistroEstudiante(110, "Luis"));
        arbol.insert(new RegistroEstudiante(101, "Carlos"));
        arbol.insert(new RegistroEstudiante(120, "Camila"));
        arbol.insert(new RegistroEstudiante(108, "Karina"));
        arbol.insert(new RegistroEstudiante(108, "Rosa")); // Duplicado intencional
        arbol.insert(new RegistroEstudiante(132, "Ernesto"));
        arbol.insert(new RegistroEstudiante(128, "Juan"));

        Scanner sc = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n--- MENÚ ---");
            System.out.println("1. Buscar estudiante");
            System.out.println("2. Eliminar estudiante");
            System.out.println("3. Insertar nuevo estudiante");
            System.out.println("4. Mostrar árbol");
            System.out.println("5. Salir");
            System.out.print("Opción: ");
            opcion = sc.nextInt();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese código de estudiante: ");
                    int codigoBuscar = sc.nextInt();
                    String nombre = arbol.buscarNombre(codigoBuscar);
                    System.out.println("Resultado: " + nombre);
                    break;
                case 2:
                    System.out.print("Ingrese código de estudiante a eliminar: ");
                    int codigoEliminar = sc.nextInt();
                    arbol.remove(new RegistroEstudiante(codigoEliminar, ""));
                    System.out.println("Eliminado (si existe)");
                    break;
                case 3:
                    System.out.print("Ingrese código del nuevo estudiante: ");
                    int codigoNuevo = sc.nextInt();
                    sc.nextLine(); // limpiar buffer
                    System.out.print("Ingrese nombre del nuevo estudiante: ");
                    String nombreNuevo = sc.nextLine();
                    arbol.insert(new RegistroEstudiante(codigoNuevo, nombreNuevo));
                    System.out.println("Insertado exitosamente.");
                    break;
                case 4:
                    arbol.printTree();
                    break;
                case 5:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        } while (opcion != 5);

        sc.close();
    }
}
