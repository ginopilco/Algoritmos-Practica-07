package btree;

import java.util.*;

public class BNode<E extends Comparable<E>> {
    List<E> claves;
    List<BNode<E>> hijos;
    boolean hoja;

    public BNode(boolean hoja) {
        this.hoja = hoja;
        this.claves = new ArrayList<>();
        this.hijos = new ArrayList<>();
    }

    public boolean esHoja() {
        return hoja;
    }
}

