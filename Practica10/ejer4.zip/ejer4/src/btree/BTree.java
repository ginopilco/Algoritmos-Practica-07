package btree;

import java.util.*;

public class BTree<E extends Comparable<E>> {
    private int orden;
    BNode<E> root;

    public BTree(int orden) {
        this.orden = orden;
        this.root = new BNode<>(true);
    }

    public void insert(E clave) {
        BNode<E> r = root;
        if (r.claves.size() == 2 * orden - 1) {
            BNode<E> s = new BNode<>(false);
            s.hijos.add(r);
            splitChild(s, 0);
            insertNonFull(s, clave);
            root = s;
        } else {
            insertNonFull(r, clave);
        }
    }

    private void insertNonFull(BNode<E> x, E clave) {
        int i = x.claves.size() - 1;
        if (x.esHoja()) {
            x.claves.add(null);
            while (i >= 0 && clave.compareTo(x.claves.get(i)) < 0) {
                x.claves.set(i + 1, x.claves.get(i));
                i--;
            }
            x.claves.set(i + 1, clave);
        } else {
            while (i >= 0 && clave.compareTo(x.claves.get(i)) < 0) {
                i--;
            }
            i++;
            if (x.hijos.get(i).claves.size() == 2 * orden - 1) {
                splitChild(x, i);
                if (clave.compareTo(x.claves.get(i)) > 0) {
                    i++;
                }
            }
            insertNonFull(x.hijos.get(i), clave);
        }
    }

    private void splitChild(BNode<E> x, int i) {
        BNode<E> y = x.hijos.get(i);
        BNode<E> z = new BNode<>(y.hoja);
        for (int j = 0; j < orden - 1; j++) {
            z.claves.add(y.claves.remove(orden));
        }
        if (!y.esHoja()) {
            for (int j = 0; j < orden; j++) {
                z.hijos.add(y.hijos.remove(orden));
            }
        }
        x.hijos.add(i + 1, z);
        x.claves.add(i, y.claves.remove(orden - 1));
    }

    public String buscarNombre(int codigo) {
        RegistroEstudiante resultado = buscarNombreRecursivo(root, codigo);
        return resultado != null ? resultado.getNombre() : "No encontrado";
    }

    private RegistroEstudiante buscarNombreRecursivo(BNode<E> nodo, int codigo) {
        if (nodo == null) return null;

        for (int i = 0; i < nodo.claves.size(); i++) {
            RegistroEstudiante actual = (RegistroEstudiante) nodo.claves.get(i);
            if (actual.getCodigo() == codigo) {
                return actual;
            } else if (codigo < actual.getCodigo() && !nodo.esHoja()) {
                return buscarNombreRecursivo(nodo.hijos.get(i), codigo);
            }
        }

        if (!nodo.esHoja()) {
            return buscarNombreRecursivo(nodo.hijos.get(nodo.claves.size()), codigo);
        }

        return null;
    }

    public void printTree() {
        printRecursive(root, 0);
    }

    private void printRecursive(BNode<E> nodo, int nivel) {
        if (nodo != null) {
            System.out.print("Nivel " + nivel + ": ");
            for (E clave : nodo.claves) {
                System.out.print(clave + " | ");
            }
            System.out.println();
            for (BNode<E> hijo : nodo.hijos) {
                printRecursive(hijo, nivel + 1);
            }
        }
    }

    public void remove(E clave) {
    }
} 
