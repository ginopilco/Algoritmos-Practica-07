package btree;

import java.util.ArrayList;

public class BNode<E extends Comparable<E>> {
    private static int nodeCounter = 0;
    protected int idNode;
    protected ArrayList<E> keys;
    protected ArrayList<BNode<E>> childs;
    protected int count;

    public BNode(int n) {
        this.idNode = ++nodeCounter;
        this.keys = new ArrayList<>(n);
        this.childs = new ArrayList<>(n + 1);
        this.count = 0;

        for (int i = 0; i < n; i++) keys.add(null);
        for (int i = 0; i <= n; i++) childs.add(null);
    }

    public boolean nodeFull(int maxKeys) {
        return count == maxKeys;
    }

    public boolean nodeEmpty() {
        return count == 0;
    }

    public boolean searchNode(E key, int[] pos) {
        int i = 0;
        while (i < count && key.compareTo(keys.get(i)) > 0) i++;
        pos[0] = i;
        return i < count && key.compareTo(keys.get(i)) == 0;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Nodo ID ").append(idNode).append(": ");
        for (int i = 0; i < count; i++) {
            sb.append(keys.get(i)).append(" ");
        }
        return sb.toString();
    }
}
