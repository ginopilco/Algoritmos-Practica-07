package btree;

public class BTree<E extends Comparable<E>> {
    private BNode<E> root;
    private final int orden;

    public BTree(int orden) {
        this.orden = orden;
        this.root = null;
    }

    public boolean isEmpty() {
        return root == null;
    }

    // ----------------------------- INSERT -----------------------------
    public void insert(E cl) {
        if (root == null) {
            root = new BNode<>(orden);
            root.keys.set(0, cl);
            root.count = 1;
            return;
        }

        if (root.count == orden - 1) {
            BNode<E> newRoot = new BNode<>(orden);
            newRoot.childs.set(0, root);
            split(newRoot, 0, root);
            root = newRoot;
        }

        insertNonFull(root, cl);
    }

    private void insertNonFull(BNode<E> node, E cl) {
        int i = node.count - 1;

        if (isLeaf(node)) {
            while (i >= 0 && cl.compareTo(node.keys.get(i)) < 0) {
                node.keys.set(i + 1, node.keys.get(i));
                i--;
            }
            node.keys.set(i + 1, cl);
            node.count++;
        } else {
            while (i >= 0 && cl.compareTo(node.keys.get(i)) < 0) {
                i--;
            }
            i++;
            if (node.childs.get(i).count == orden - 1) {
                split(node, i, node.childs.get(i));
                if (cl.compareTo(node.keys.get(i)) > 0) {
                    i++;
                }
            }
            insertNonFull(node.childs.get(i), cl);
        }
    }

    private void split(BNode<E> parent, int index, BNode<E> child) {
        BNode<E> newNode = new BNode<>(orden);
        int mid = orden / 2;

        newNode.count = orden - 1 - mid - 1;
        for (int j = 0; j < newNode.count; j++) {
            newNode.keys.set(j, child.keys.get(mid + 1 + j));
        }

        if (!isLeaf(child)) {
            for (int j = 0; j <= newNode.count; j++) {
                newNode.childs.set(j, child.childs.get(mid + 1 + j));
            }
        }

        for (int j = parent.count; j > index; j--) {
            parent.childs.set(j + 1, parent.childs.get(j));
            parent.keys.set(j, parent.keys.get(j - 1));
        }

        parent.childs.set(index + 1, newNode);
        parent.keys.set(index, child.keys.get(mid));
        parent.count++;

        child.count = mid;
    }

    private boolean isLeaf(BNode<E> node) {
        return node.childs.get(0) == null;
    }

    // ----------------------------- SEARCH -----------------------------
    public boolean search(E cl) {
        return searchRecursive(this.root, cl);
    }

    private boolean searchRecursive(BNode<E> node, E cl) {
        if (node == null) return false;

        int i = 0;
        while (i < node.count && cl.compareTo(node.keys.get(i)) > 0) {
            i++;
        }

        if (i < node.count && cl.compareTo(node.keys.get(i)) == 0) {
            System.out.println(cl + " se encuentra en el nodo " + node.idNode + " en la posición " + i);
            return true;
        }

        if (isLeaf(node)) return false;

        return searchRecursive(node.childs.get(i), cl);
    }

    // ----------------------------- REMOVE -----------------------------
    public void remove(E cl) {
        if (root == null) return;

        deleteRecursive(root, cl);

        if (root.count == 0 && !isLeaf(root)) {
            root = root.childs.get(0);
        }

        if (root.count == 0 && isLeaf(root)) {
            root = null;
        }
    }

    private void deleteRecursive(BNode<E> node, E cl) {
        int idx = 0;
        while (idx < node.count && cl.compareTo(node.keys.get(idx)) > 0) {
            idx++;
        }

        if (idx < node.count && cl.compareTo(node.keys.get(idx)) == 0) {
            if (isLeaf(node)) {
                for (int i = idx; i < node.count - 1; i++) {
                    node.keys.set(i, node.keys.get(i + 1));
                }
                node.keys.set(node.count - 1, null);
                node.count--;
            } else {
                BNode<E> predChild = node.childs.get(idx);
                BNode<E> succChild = node.childs.get(idx + 1);

                if (predChild.count >= (orden / 2)) {
                    E pred = getMax(predChild);
                    node.keys.set(idx, pred);
                    deleteRecursive(predChild, pred);
                } else if (succChild.count >= (orden / 2)) {
                    E succ = getMin(succChild);
                    node.keys.set(idx, succ);
                    deleteRecursive(succChild, succ);
                } else {
                    merge(node, idx);
                    deleteRecursive(predChild, cl);
                }
            }
        } else {
            if (isLeaf(node)) return;

            BNode<E> child = node.childs.get(idx);

            if (child.count < (orden / 2)) {
                BNode<E> leftSibling = (idx > 0) ? node.childs.get(idx - 1) : null;
                BNode<E> rightSibling = (idx < node.count) ? node.childs.get(idx + 1) : null;

                if (leftSibling != null && leftSibling.count >= (orden / 2)) {
                    rotateRight(node, idx - 1);
                } else if (rightSibling != null && rightSibling.count >= (orden / 2)) {
                    rotateLeft(node, idx);
                } else {
                    if (leftSibling != null) {
                        merge(node, idx - 1);
                        child = node.childs.get(idx - 1);
                    } else {
                        merge(node, idx);
                    }
                }
            }

            deleteRecursive(node.childs.get(idx), cl);
        }
    }

    private E getMax(BNode<E> node) {
        while (!isLeaf(node)) {
            node = node.childs.get(node.count);
        }
        return node.keys.get(node.count - 1);
    }

    private E getMin(BNode<E> node) {
        while (!isLeaf(node)) {
            node = node.childs.get(0);
        }
        return node.keys.get(0);
    }

    private void rotateLeft(BNode<E> parent, int idx) {
        BNode<E> child = parent.childs.get(idx);
        BNode<E> rightSibling = parent.childs.get(idx + 1);

        child.keys.set(child.count, parent.keys.get(idx));
        child.count++;

        parent.keys.set(idx, rightSibling.keys.get(0));

        for (int i = 0; i < rightSibling.count - 1; i++) {
            rightSibling.keys.set(i, rightSibling.keys.get(i + 1));
        }

        if (!isLeaf(child)) {
            child.childs.set(child.count, rightSibling.childs.get(0));
            for (int i = 0; i < rightSibling.count; i++) {
                rightSibling.childs.set(i, rightSibling.childs.get(i + 1));
            }
        }

        rightSibling.count--;
    }

    private void rotateRight(BNode<E> parent, int idx) {
        BNode<E> leftSibling = parent.childs.get(idx);
        BNode<E> child = parent.childs.get(idx + 1);

        for (int i = child.count; i > 0; i--) {
            child.keys.set(i, child.keys.get(i - 1));
        }

        if (!isLeaf(child)) {
            for (int i = child.count + 1; i > 0; i--) {
                child.childs.set(i, child.childs.get(i - 1));
            }
        }

        child.keys.set(0, parent.keys.get(idx));
        if (!isLeaf(child)) {
            child.childs.set(0, leftSibling.childs.get(leftSibling.count));
        }

        parent.keys.set(idx, leftSibling.keys.get(leftSibling.count - 1));
        leftSibling.keys.set(leftSibling.count - 1, null);
        leftSibling.count--;

        child.count++;
    }

    private void merge(BNode<E> parent, int index) {
        BNode<E> child = parent.childs.get(index);
        BNode<E> sibling = parent.childs.get(index + 1);

        child.keys.set(child.count, parent.keys.get(index));
        for (int i = 0; i < sibling.count; i++) {
            child.keys.set(child.count + 1 + i, sibling.keys.get(i));
            child.childs.set(child.count + 1 + i, sibling.childs.get(i));
        }
        child.childs.set(child.count + 1 + sibling.count, sibling.childs.get(sibling.count));
        child.count += sibling.count + 1;

        for (int i = index; i < parent.count - 1; i++) {
            parent.keys.set(i, parent.keys.get(i + 1));
            parent.childs.set(i + 1, parent.childs.get(i + 2));
        }
        parent.keys.set(parent.count - 1, null);
        parent.childs.set(parent.count, null);
        parent.count--;
    }

    // ----------------------------- TO STRING -----------------------------
    public String toString() {
        if (isEmpty()) return "Árbol B vacío.";
        return writeTree(this.root);
    }

    private String writeTree(BNode<E> current) {
        if (current == null) return "";
        StringBuilder sb = new StringBuilder();
        sb.append(current.toString()).append("\n");
        for (int i = 0; i <= current.count; i++) {
            sb.append(writeTree(current.childs.get(i)));
        }
        return sb.toString();
    }
}
