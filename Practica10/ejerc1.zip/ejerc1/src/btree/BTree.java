package btree;

public class BTree<E extends Comparable<E>> {
    private BNode<E> root;
    private int orden;
    private boolean up;
    private BNode<E> nDes;

    public BTree(int orden) {
        this.orden = orden;
        this.root = null;
    }

    public boolean isEmpty() {
        return this.root == null;
    }

    public void insert(E cl) {
        up = false;
        E mediana = push(this.root, cl);
        if (up) {
            BNode<E> pnew = new BNode<>(orden);
            pnew.count = 1;
            pnew.keys.set(0, mediana);
            pnew.childs.set(0, this.root);
            pnew.childs.set(1, nDes);
            this.root = pnew;
        }
    }

    private E push(BNode<E> current, E cl) {
        int[] pos = new int[1];
        E mediana;

        if (current == null) {
            up = true;
            nDes = null;
            return cl;
        } else {
            boolean found = current.searchNode(cl, pos);
            if (found) {
                System.out.println("Elemento duplicado.");
                up = false;
                return null;
            }

            mediana = push(current.childs.get(pos[0]), cl);

            if (up) {
                if (current.nodeFull(orden - 1)) {
                    mediana = dividedNode(current, mediana, pos[0]);
                } else {
                    up = false;
                    putNode(current, mediana, nDes, pos[0]);
                }
            }

            return mediana;
        }
    }

    private void putNode(BNode<E> current, E cl, BNode<E> rd, int k) {
        for (int i = current.count - 1; i >= k; i--) {
            current.keys.set(i + 1, current.keys.get(i));
            current.childs.set(i + 2, current.childs.get(i + 1));
        }
        current.keys.set(k, cl);
        current.childs.set(k + 1, rd);
        current.count++;
    }

    private E dividedNode(BNode<E> current, E cl, int k) {
        BNode<E> rd = nDes;
        int i, posMdna = (k <= orden / 2) ? orden / 2 : (orden / 2 + 1);
        nDes = new BNode<>(orden);

        for (i = posMdna; i < orden - 1; i++) {
            nDes.keys.set(i - posMdna, current.keys.get(i));
            nDes.childs.set(i - posMdna + 1, current.childs.get(i + 1));
        }

        nDes.count = (orden - 1) - posMdna;
        current.count = posMdna;

        if (k <= orden / 2) {
            putNode(current, cl, rd, k);
        } else {
            putNode(nDes, cl, rd, k - posMdna);
        }

        E median = current.keys.get(current.count - 1);
        nDes.childs.set(0, current.childs.get(current.count));
        current.count--;

        return median;
    }

    public boolean search(E cl) {
        return searchRecursive(this.root, cl);
    }
    
    private boolean searchRecursive(BNode<E> node, E cl) {
        if (node == null) return false;
    
        int i = 0;
        // Buscar la clave en el nodo actual
        while (i < node.count && cl.compareTo(node.keys.get(i)) > 0) {
            i++;
        }
    
        if (i < node.count && cl.compareTo(node.keys.get(i)) == 0) {
            // Clave encontrada
            System.out.println(cl + " se encuentra en el nodo " + node.idNode + " en la posición " + i);
            return true;
        }
    
        // Si es hoja y no se encontró, retornar false
        if (node.childs.get(i) == null) {
            return false;
        }
    
        // Buscar recursivamente en el hijo correspondiente
        return searchRecursive(node.childs.get(i), cl);
    }
    

    public void delete(E key) {
        deleteInternal(root, key);
        if (root.count == 0 && !isLeaf(root)) {
            root = root.childs.get(0); // reducir altura
        }
    }

    private void deleteInternal(BNode<E> node, E key) {
        int[] pos = new int[1];
        boolean found = node.searchNode(key, pos);

        if (found) {
            if (isLeaf(node)) {
                // eliminar directamente
                removeFromNode(node, pos[0]);
            } else {
                // buscar predecesor
                BNode<E> predNode = node.childs.get(pos[0]);
                while (!isLeaf(predNode)) predNode = predNode.childs.get(predNode.count);
                E pred = predNode.keys.get(predNode.count - 1);
                node.keys.set(pos[0], pred);
                deleteInternal(node.childs.get(pos[0]), pred);
            }
        } else {
            BNode<E> child = node.childs.get(pos[0]);
            if (child == null) return;

            if (child.count <= (orden - 1) / 2) {
                fixChild(node, pos[0]);
            }
            deleteInternal(node.childs.get(pos[0]), key);
        }
    }

    private void removeFromNode(BNode<E> node, int pos) {
        for (int i = pos; i < node.count - 1; i++) {
            node.keys.set(i, node.keys.get(i + 1));
        }
        node.keys.set(node.count - 1, null);
        node.count--;
    }

    private void fixChild(BNode<E> parent, int index) {
        BNode<E> left = index > 0 ? parent.childs.get(index - 1) : null;
        BNode<E> right = index < parent.count ? parent.childs.get(index + 1) : null;
        BNode<E> current = parent.childs.get(index);

        if (left != null && left.count > (orden - 1) / 2) {
            // rotar desde la izquierda
            for (int i = current.count; i > 0; i--) {
                current.keys.set(i, current.keys.get(i - 1));
                current.childs.set(i + 1, current.childs.get(i));
            }
            current.childs.set(1, current.childs.get(0));
            current.keys.set(0, parent.keys.get(index - 1));
            current.childs.set(0, left.childs.get(left.count));
            current.count++;

            parent.keys.set(index - 1, left.keys.get(left.count - 1));
            left.count--;
        } else if (right != null && right.count > (orden - 1) / 2) {
            // rotar desde la derecha
            current.keys.set(current.count, parent.keys.get(index));
            current.childs.set(current.count + 1, right.childs.get(0));
            parent.keys.set(index, right.keys.get(0));

            for (int i = 0; i < right.count - 1; i++) {
                right.keys.set(i, right.keys.get(i + 1));
                right.childs.set(i, right.childs.get(i + 1));
            }
            right.childs.set(right.count - 1, right.childs.get(right.count));
            right.count--;
            current.count++;
        } else {
            // fusión con hermano
            if (right != null) {
                merge(parent, index);
            } else if (left != null) {
                merge(parent, index - 1);
            }
        }
    }

    private void merge(BNode<E> parent, int index) {
        BNode<E> child = parent.childs.get(index);
        BNode<E> sibling = parent.childs.get(index + 1);

        child.keys.set(child.count, parent.keys.get(index));
        for (int i = 0; i < sibling.count; i++) {
            child.keys.set(child.count + 1 + i, sibling.keys.get(i));
            child.childs.set(child.count + 1 + i, sibling.childs.get(i));
        }
        child.childs.set(child.count + 1 + sibling.count, sibling.childs.get(sibling.count));
        child.count += sibling.count + 1;

        for (int i = index; i < parent.count - 1; i++) {
            parent.keys.set(i, parent.keys.get(i + 1));
            parent.childs.set(i + 1, parent.childs.get(i + 2));
        }
        parent.keys.set(parent.count - 1, null);
        parent.childs.set(parent.count, null);
        parent.count--;
    }

    private boolean isLeaf(BNode<E> node) {
        return node.childs.get(0) == null;
    }

    public String toString() {
        if (isEmpty()) return "Árbol B vacío.";
        return writeTree(this.root);
    }

    private String writeTree(BNode<E> current) {
        if (current == null) return "";
        StringBuilder sb = new StringBuilder();
        sb.append(current.toString()).append("\n");
        for (int i = 0; i <= current.count; i++) {
            sb.append(writeTree(current.childs.get(i)));
        }
        return sb.toString();
    }
}
