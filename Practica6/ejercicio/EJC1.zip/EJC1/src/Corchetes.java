package EJC1.src;

public class Corchetes {
    public static boolean estaBalanceado(String S) throws ExceptionIsEmpty {
        StackLink<Character> pila = new StackLink<>();
        for (int i = 0; i < S.length(); i++) {
            char caracter = S.charAt(i);
            if (caracter == '(' || caracter == '[' || caracter == '{') {
                pila.push(caracter);
            } else if (caracter == ')' || caracter == ']' || caracter == '}') {
                if (pila.isEmpty()) return false;
                char tope = pila.top();
                if ((caracter == ')' && tope == '(') ||
                    (caracter == ']' && tope == '[') ||
                    (caracter == '}' && tope == '{')) {
                    pila.pop();
                } else {
                    return false;
                }
            }
        }
        return pila.isEmpty();
    }

    public static void main(String[] args) throws ExceptionIsEmpty {
        String ejemplo1 = "()()()[()]()";
        String ejemplo2 = "([])[](";
        System.out.println("El ejemplo 1 está balanceado: " + estaBalanceado(ejemplo1));
        System.out.println("El ejemplo 2 está balanceado: " + estaBalanceado(ejemplo2));
    }
}
