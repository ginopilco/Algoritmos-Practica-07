package EJC1.src;

public class TestPriorityQueueLinked {
    public static void main(String[] args) {
        PriorityQueueLinked<String, Integer> priorityQueue = new PriorityQueueLinked<>(3);

        priorityQueue.enqueue("Elemento 1", 2);
        priorityQueue.enqueue("Elemento 2", 1);
        priorityQueue.enqueue("Elemento 3", 0);
        priorityQueue.enqueue("Elemento 4", 1);
        priorityQueue.enqueue("Elemento 5", 2);

        System.out.println("Cola de prioridad:");
        System.out.println(priorityQueue);

        try {
            System.out.println("Elemento dequeue(): " + priorityQueue.dequeue());
            System.out.println("Elemento front(): " + priorityQueue.front());
            System.out.println("Elemento back(): " + priorityQueue.back());
            System.out.println("¿La cola está vacía? " + priorityQueue.isEmpty());
        } catch (ExceptionIsEmpty e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
