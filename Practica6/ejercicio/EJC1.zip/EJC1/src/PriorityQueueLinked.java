package EJC1.src;

import act1.ExceptionIsEmpty;
import act2.QueueLink;
import act3.PriorityQueue;

import java.util.logging.Level;
import java.util.logging.Logger;

public class PriorityQueueLinked<E, P extends Comparable<P>> implements PriorityQueue<E, P> {
    private final QueueLink<E>[] queues;
    private final int numPriorities;

    @SuppressWarnings("unchecked")
    public PriorityQueueLinked(int numPriorities) {
        this.numPriorities = numPriorities;
        this.queues = new QueueLink[numPriorities];
        for (int i = 0; i < numPriorities; i++) {
            this.queues[i] = new QueueLink<>();
        }
    }

    @Override
    public void enqueue(E data, P priority) {
        int index = priorityToIndex(priority);
        queues[index].enqueue(data);
    }

    @Override
    public E dequeue() throws ExceptionIsEmpty {
        for (int i = 0; i < numPriorities; i++) {
            if (!queues[i].isEmpty()) {
                return queues[i].dequeue();
            }
        }
        throw new ExceptionIsEmpty();
    }

    @Override
    public E front() throws ExceptionIsEmpty {
        for (int i = 0; i < numPriorities; i++) {
            if (!queues[i].isEmpty()) {
                return queues[i].front();
            }
        }
        throw new ExceptionIsEmpty();
    }

    @Override
    public E back() throws ExceptionIsEmpty {
        for (int i = numPriorities - 1; i >= 0; i--) {
            if (!queues[i].isEmpty()) {
                return queues[i].back();
            }
        }
        throw new ExceptionIsEmpty();
    }

    @Override
    public boolean isEmpty() {
        for (QueueLink<E> queue : queues) {
            if (!queue.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < numPriorities; i++) {
            result.append("Priority ").append(i).append(": ")
                  .append(queues[i].toString()).append("\n");
        }
        return result.toString();
    }

    private int priorityToIndex(P priority) {
        if (priority instanceof Integer) {
            return (Integer) priority;
        } else if (priority instanceof Enum) {
            return ((Enum<?>) priority).ordinal();
        } else {
            throw new IllegalArgumentException("Tipo de prioridad inválido.");
        }
    }
}
