package EJC1.src;

public class CorchetesExtra {
    public static boolean tieneCorchetesAdicionales(String exp) throws ExceptionIsEmpty {
        StackLink<Character> pila = new StackLink<>();
        for (int i = 0; i < exp.length(); i++) {
            char caracter = exp.charAt(i);
            if (caracter == '(') {
                if (i + 1 < exp.length() && exp.charAt(i + 1) == ')') {
                    return true; // Corchetes innecesarios
                }
                pila.push(caracter);
            } else if (caracter == ')') {
                if (!pila.isEmpty() && pila.top() == '(') {
                    pila.pop();
                } else {
                    return true;
                }
            }
        }
        return !pila.isEmpty();
    }

    public static void main(String[] args) throws ExceptionIsEmpty {
        String exp1 = "((a+b)+(c+d))";
        String exp2 = "(a+b)+((c+d))";
        String exp3 = "(a+b)-(c+d)";
        System.out.println("La expresión 1 tiene corchetes adicionales: " + tieneCorchetesAdicionales(exp1));
        System.out.println("La expresión 2 tiene corchetes adicionales: " + tieneCorchetesAdicionales(exp2));
        System.out.println("La expresión 3 tiene corchetes adicionales: " + tieneCorchetesAdicionales(exp3));
    }
}
