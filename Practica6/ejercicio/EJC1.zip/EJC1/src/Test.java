package EJC1.src;

public class Test {
    public static void main(String[] args) {
        Stack<Integer> integerStack = new StackLink<>();
        integerStack.push(1);
        integerStack.push(2);
        integerStack.push(3);

        try {
            System.out.println("Elemento en la cima de la pila: " + integerStack.top());
            System.out.println("Elemento eliminado de la pila: " + integerStack.pop());
            System.out.println("Pila después de eliminar un elemento: " + integerStack.toString());
        } catch (ExceptionIsEmpty e) {
            System.out.println("Error: La pila está vacía.");
        }
    }
}
