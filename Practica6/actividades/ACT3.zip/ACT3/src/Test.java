package ACT3;

public class Test {
    public static void main(String[] args) {
        PriorityQueue<Integer, Integer> priorityQueue = new PriorityQueueLinkSort<>();
        priorityQueue.enqueue(1, 2);
        priorityQueue.enqueue(2, 1);
        priorityQueue.enqueue(3, 3);
        try {
            System.out.println("Primer elemento de la cola de prioridad: " + priorityQueue.front());
            System.out.println("Último elemento de la cola de prioridad: " + priorityQueue.back());
            System.out.println("Elemento eliminado de la cola de prioridad: " + priorityQueue.dequeue());
            System.out.println("Primer elemento después de eliminar: " + priorityQueue.front());
            System.out.println("Cola de prioridad: " + priorityQueue.toString());
        } catch (ExceptionIsEmpty e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
