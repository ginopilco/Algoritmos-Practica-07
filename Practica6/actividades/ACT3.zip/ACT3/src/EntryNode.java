package ACT3.src;

public class EntryNode<E, P extends Comparable<P>> {
    private E data;
    private P priority;

    public EntryNode(E data, P priority) {
        this.data = data;
        this.priority = priority;
    }

    public E getData() {
        return data;
    }

    public P getPriority() {
        return priority;
    }
}
