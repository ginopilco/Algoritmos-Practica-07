package ACT3.src;

public class PriorityQueueLinkSort<E, P extends Comparable<P>> implements PriorityQueue<E, P> {
    private Node<EntryNode<E, P>> first;
    private Node<EntryNode<E, P>> last;

    public PriorityQueueLinkSort() {
        this.first = null;
        this.last = null;
    }

    public void enqueue(E data, P priority) {
        EntryNode<E, P> newEntry = new EntryNode<>(data, priority);
        Node<EntryNode<E, P>> newNode = new Node<>(newEntry);

        if (isEmpty() || priority.compareTo(first.getData().getPriority()) > 0) {
            newNode.setNext(first);
            first = newNode;
        } else {
            Node<EntryNode<E, P>> current = first;
            while (current.getNext() != null &&
                   priority.compareTo(current.getNext().getData().getPriority()) <= 0) {
                current = current.getNext();
            }
            newNode.setNext(current.getNext());
            current.setNext(newNode);
        }

        if (newNode.getNext() == null) {
            last = newNode;
        }
    }

    public E dequeue() throws ExceptionIsEmpty {
        if (isEmpty()) {
            throw new ExceptionIsEmpty();
        }
        E data = first.getData().getData();
        first = first.getNext();
        if (first == null) {
            last = null;
        }
        return data;
    }

    public E front() throws ExceptionIsEmpty {
        if (isEmpty()) {
            throw new ExceptionIsEmpty();
        }
        return first.getData().getData();
    }

    public E back() throws ExceptionIsEmpty {
        if (isEmpty()) {
            throw new ExceptionIsEmpty();
        }
        return last.getData().getData();
    }

    public boolean isEmpty() {
        return first == null;
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder("[");
        Node<EntryNode<E, P>> current = first;
        while (current != null) {
            result.append(current.getData().getData())
                  .append("(")
                  .append(current.getData().getPriority())
                  .append(")");
            if (current.getNext() != null) {
                result.append(", ");
            }
            current = current.getNext();
        }
        result.append("]");
        return result.toString();
    }
}
