import actividad2.*;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Queue<Integer> cola = new QueueLink<>();  // QueueLink implementar la cola
        boolean exit = false;

        while (!exit) {
            System.out.println("\n Menu de Operaciones ");
            System.out.println("1) Agregar");
            System.out.println("2) Eliminar");
            System.out.println("3) Ver el frente");
            System.out.println("4) Ultimo elemento");
            System.out.println("5) Cola completa");
            System.out.println("6) Cola está vacía");
            System.out.println("7) Salir");
            System.out.print("Selecciona una opcion: ");
            int opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el numero para encolar: ");
                    int num = scanner.nextInt();
                    cola.enqueue(num);
                    System.out.println(num + " agregado");
                    break;

                case 2:
                    try {
                        int eliminado = cola.dequeue();
                        System.out.println("Se ha eliminado: " + eliminado);
                    } catch (ExceptionIsEmpty e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 3:
                    try {
                        int frente = cola.front();
                        System.out.println("El frente de la cola es: " + frente);
                    } catch (ExceptionIsEmpty e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 4:
                    try {
                        int ultimo = cola.back();
                        System.out.println("El último elemento en la cola es: " + ultimo);
                    } catch (ExceptionIsEmpty e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 5:
                ((QueueLink<Integer>) cola).mostrarCola();  // cola completa

                    break;

                case 6:
                    if (cola.isEmpty()) {
                        System.out.println("La cola está vacía.");
                    } else {
                        System.out.println("La cola no está vacía.");
                    }
                    break;

                case 7:
                    System.out.println("Saliendo");
                    exit = true;
                    break;

                default:
                    System.out.println("Opción no válida, intenta de nuevo.");
                    break;
            }
        }

        scanner.close();
    }
}
