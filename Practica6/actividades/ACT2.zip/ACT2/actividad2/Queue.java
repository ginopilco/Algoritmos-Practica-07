package actividad2;

public interface Queue<E> {
    void enqueue(E x);  // Encolar (insertar en la cola)
    E dequeue() throws ExceptionIsEmpty;  // Desencolar (eliminar del frente)
    E front() throws ExceptionIsEmpty;    // Ver el primer elemento
    E back() throws ExceptionIsEmpty;     // Ver el último elemento
    boolean isEmpty();  // Verificar si la cola está vacía
}
