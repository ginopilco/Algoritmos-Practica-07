
package actividad2;
public class QueueLink<E> implements Queue<E> {
    private Node<E> front;
    private Node<E> back;

    public QueueLink() {
        this.front = null;
        this.back = null;
    }

    @Override
    public void enqueue(E e) {
        Node<E> newNode = new Node<>(e);
        if (back != null) {
            back.setNext(newNode);
        }
        back = newNode;
        if (front == null) {
            front = newNode;
        }
    }

    @Override
    public E dequeue() throws ExceptionIsEmpty {
        if (isEmpty()) {
            throw new ExceptionIsEmpty("La cola está vacía.");
        }
        E data = front.getData();
        front = front.getNext();
        if (front == null) {
            back = null;
        }
        return data;
    }

    @Override
    public E front() throws ExceptionIsEmpty {
        if (isEmpty()) {
            throw new ExceptionIsEmpty("La cola está vacía.");
        }
        return front.getData();
    }

    @Override
    public E back() throws ExceptionIsEmpty {
        if (isEmpty()) {
            throw new ExceptionIsEmpty("La cola está vacía.");
        }
        return back.getData();
    }

    @Override
    public boolean isEmpty() {
        return front == null;
    }

    // Nuevo método para ver la cola completa
    public void mostrarCola() {
        if (isEmpty()) {
            System.out.println("La cola está vacía.");
            return;
        }

        Node<E> current = front;
        System.out.print("Cola: ");
        while (current != null) {
            System.out.print(current.getData() + " ");
            current = current.getNext();
        }
        System.out.println();
    }
}
