import actividad1.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Stack<Integer> pila = new StackArray<>(5); // Tamaño fijo

        int opcion;
        do {
            System.out.println("\n MENU DE PILA ");
            System.out.println("1) Push ");
            System.out.println("2) Top ");
            System.out.println("3) Pop ");
            System.out.println("4) Mostrar pila");
            System.out.println("5) Salir");
            System.out.print("Elige una opcion: ");
            opcion = sc.nextInt();

            try {
                switch (opcion) {
                    case 1:
                        if (((StackArray<Integer>) pila).isFull()) {
                            System.out.println("La pila está llena.");
                        } else {
                            System.out.print("Ingrese un numero: ");
                            int num = sc.nextInt();
                            pila.push(num);
                        }
                        break;
                    case 2:
                        System.out.println("Elemento top: " + pila.top());
                        break;
                    case 3:
                        pila.pop();
                        System.out.println("Elemento eliminado");
                        break;
                    case 4:
                        System.out.println("Pila: " + pila);
                        break;
                    case 5:
                        System.out.println("Saliendo");
                        break;
                    default:
                        System.out.println("Opcion no valida");
                }
            } catch (ExceptionIsEmpty e) {
                System.out.println("Error: " + e.getMessage());
            }

        } while (opcion != 5);

        sc.close();
    }
}
