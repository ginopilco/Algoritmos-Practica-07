package mejora;
import java.util.Arrays;
public class BusquedaLineal {

    // Búsqueda lineal
    public static int busquedaLineal(int[] arr, int x) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == x) return i;
        }
        return -1;
    }

    public static void main(String[] args) {
        int[] arr = {12, 1, 7, 5, 6, 2};
        System.out.println("Arreglo original: " + Arrays.toString(arr));

        int numBuscado = 6;
        int index = busquedaLineal(arr, numBuscado);

        if (index != -1) {
            System.out.println("Número encontrado en el índice: " + index);
        } else {
            System.out.println("Número no encontrado");
        }
    }
}
