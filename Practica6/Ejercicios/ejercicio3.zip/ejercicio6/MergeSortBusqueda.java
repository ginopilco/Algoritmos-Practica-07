import java.util.Arrays;

public class MergeSortBusqueda {

    // Método Merge Sort
    public static void mergeSort(int[] arr) {
        if (arr.length < 2) return; //solo 1 ya esta ordenado
        int mid = arr.length / 2;
        int[] left = Arrays.copyOfRange(arr, 0, mid); //sub arreglo iz
        int[] right = Arrays.copyOfRange(arr, mid, arr.length); //sub arreglo dere
        mergeSort(left); //llama recursivamente a mergesort para ordenar 
        mergeSort(right);
        merge(arr, left, right);
    }

    public static void merge(int[] arr, int[] left, int[] right) {
        int i = 0, j = 0, k = 0;  //indices left, righ , raid
        while (i < left.length && j < right.length) {
            arr[k++] = (left[i] <= right[j]) ? left[i++] : right[j++]; //compara los subarreglos y pone el menor
        }
        //agrega subarreglos 
        while (i < left.length) arr[k++] = left[i++];
        while (j < right.length) arr[k++] = right[j++];
    }

    // Método de búsqueda binaria
    public static int busquedaBinaria(int[] arr, int x) {
        int low = 0, high = arr.length - 1;
        while (low <= high) {
            int mid = low + (high - low) / 2; //indice medio
            if (arr[mid] == x) return mid; // si es el medio
            if (arr[mid] < x) low = mid + 1; //si es menor busca derecha
            else high = mid - 1; //si es mayor busca izquierda 
        }
        return -1; // No encontrado
    }

    public static void main(String[] args) {
        int[] arr = {12, 1, 7, 5, 6, 2};
        System.out.println("Arreglo original: " + Arrays.toString(arr));

        // Ordenar con Merge Sort
        mergeSort(arr);
        System.out.println("Arreglo ordenado: " + Arrays.toString(arr));

        // Buscar un número con búsqueda binaria
        int numBuscado = 6;
        int index = busquedaBinaria(arr, numBuscado);

        if (index != -1) {
            System.out.println("Número encontrado en el índice: " + index);
        } else {
            System.out.println("Número no encontrado");
        }
    }
}
