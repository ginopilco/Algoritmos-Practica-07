import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        GestorDeTareas<Tarea> gestor = new GestorDeTareas<>();
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n MENU DE TAREAS ");
            System.out.println("1) Agregar tarea");
            System.out.println("2) Eliminar tarea");
            System.out.println("3) Ver todas las tareas");
            System.out.println("4) Contar tareas");
            System.out.println("5) Invertir tareas");
            System.out.println("6) Ver tarea mas prioritaria");
            System.out.println("0) Salir");
            System.out.print("Elige una opcion: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // limpiar buffer

            switch (opcion) {
                case 1:
                    System.out.print("Descripcion: ");
                    String descripcion = scanner.nextLine();
                    System.out.print("Prioridad -+: ");
                    int prioridad = scanner.nextInt();
                    scanner.nextLine(); // limpiar buffer
                    gestor.agregarTarea(new Tarea(descripcion, prioridad));
                    System.out.println("La tarea fue agregada con exito");
                    break;

                case 2:
                    System.out.print("Descripcion exacta de la tarea: ");
                    String descEliminar = scanner.nextLine();
                    boolean eliminada = gestor.eliminarTarea(new Tarea(descEliminar, 0)); // La prioridad no importa para comparar
                    if (eliminada) {
                        System.out.println("La tarea fue eliminada");
                    } else {
                        System.out.println("La tarea no fue encontrada");
                    }
                    break;

                case 3:
                    System.out.println("Tareas actuales:");
                    gestor.imprimirTareas();
                    break;

                case 4:
                    System.out.println("Total de tareas: " + gestor.contarTareas());
                    break;

                case 5:
                    gestor.invertirTareas();
                    System.out.println("Lista de tareas invertida");
                    break;

                case 6:
                    Tarea prioridadAlta = (Tarea) gestor.obtenerTareaMasPrioritaria();
                    System.out.println("Tarea mas prioritaria: " + prioridadAlta);
                    break;

                case 0:
                    System.out.println(" Saliendo del menu");
                    break;

                default:
                    System.out.println(" Opcion invalida");
            }

        } while (opcion != 0);

        scanner.close();
    }
}
