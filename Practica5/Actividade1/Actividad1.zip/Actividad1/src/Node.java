class Node<T> {
    T tarea;           // Tarea del nodo
    Node<T> siguiente; // Apunta al siguiente nodo

    public Node(T tarea) {
        this.tarea = tarea;
        this.siguiente = null;
    }
}
