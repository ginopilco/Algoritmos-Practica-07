class GestorDeTareas<T> {
    private Node<T> cabeza;

    public GestorDeTareas() {
        cabeza = null;
    }

    // Agregar tarea al final de la lista
    public void agregarTarea(T tarea) {
        Node<T> nuevoNodo = new Node<>(tarea);
        if (cabeza == null) {
            cabeza = nuevoNodo;
        } else {
            Node<T> temp = cabeza;
            while (temp.siguiente != null) {
                temp = temp.siguiente;
            }
            temp.siguiente = nuevoNodo;
        }
    }

    // Eliminar tarea
    public boolean eliminarTarea(T tarea) {
        if (cabeza == null) return false;

        if (cabeza.tarea.equals(tarea)) {
            cabeza = cabeza.siguiente;
            return true;
        }

        Node<T> temp = cabeza;
        while (temp.siguiente != null && !temp.siguiente.tarea.equals(tarea)) {
            temp = temp.siguiente;
        }

        if (temp.siguiente == null) {
            return false;
        }

        temp.siguiente = temp.siguiente.siguiente;
        return true;
    }

    // Verificar si contiene una tarea
    public boolean contieneTarea(T tarea) {
        Node<T> temp = cabeza;
        while (temp != null) {
            if (temp.tarea.equals(tarea)) {
                return true;
            }
            temp = temp.siguiente;
        }
        return false;
    }

    // Imprimir todas las tareas
    public void imprimirTareas() {
        Node<T> temp = cabeza;
        while (temp != null) {
            System.out.println(temp.tarea);
            temp = temp.siguiente;
        }
    }

    // Contar el número de tareas
    public int contarTareas() {
        int count = 0;
        Node<T> temp = cabeza;
        while (temp != null) {
            count++;
            temp = temp.siguiente;
        }
        return count;
    }

    // Obtener la tarea más prioritaria (si se trabaja con objetos Tarea)
    public T obtenerTareaMasPrioritaria() {
        if (cabeza == null) return null;

        Node<T> temp = cabeza;
        T tareaMasPrioritaria = cabeza.tarea;
        while (temp != null) {
            if (((Tarea)temp.tarea).getPrioridad() < ((Tarea)tareaMasPrioritaria).getPrioridad()) {
                tareaMasPrioritaria = temp.tarea;
            }
            temp = temp.siguiente;
        }
        return tareaMasPrioritaria;
    }

    // Invertir la lista de tareas
    public void invertirTareas() {
        Node<T> prev = null;
        Node<T> current = cabeza;
        Node<T> next = null;
        
        while (current != null) {
            next = current.siguiente;
            current.siguiente = prev;
            prev = current;
            current = next;
        }
        cabeza = prev;
    }
}
