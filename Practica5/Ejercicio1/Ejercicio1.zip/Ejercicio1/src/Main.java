import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        
        // Probar buscarElemento
        List<Integer> numeros = List.of(4, 6, 1, 9, 2);
        System.out.println("Buscar 3: " + ListUtils.buscarElemento(numeros, 3)); // true
        System.out.println("Buscar 6: " + ListUtils.buscarElemento(numeros, 6)); // false

        
        // Probar invertirLista
        List<Integer> invertida = ListUtils.invertirLista(numeros);
        System.out.println("Lista invertida: " + invertida);

       
        // Crear lista enlazada
        Node<Integer> head = new Node<>(3);
        head = ListUtils.insertarAlFinal(head, 5);
        head = ListUtils.insertarAlFinal(head, 1);

        
        // Contar nodos
        System.out.println("Nodos en la lista: " + ListUtils.contarNodos(head));

        
        // Crear otra lista para comparar
        Node<Integer> head2 = new Node<>(9);
        head2 = ListUtils.insertarAlFinal(head2, 4);
        head2 = ListUtils.insertarAlFinal(head2, 7);

        
        // Comparar listas
        System.out.println("Listas son iguales: " + ListUtils.sonIguales(head, head2));

        
        // Concatenar listas
        Node<Integer> nuevaCabeza = ListUtils.concatenarListas(head, head2);
        System.out.print("Lista concatenada: ");
        Node<Integer> actual = nuevaCabeza;
        while (actual != null) {
            System.out.print(actual.data + " ");
            actual = actual.next;
        }
    }
}
