public class AVLTree extends BSTree {

    @Override
    protected NodeAVL insertRec(NodeBST node, int value) throws ItemDuplicated {
        if (node == null) return new NodeAVL(value);
        NodeAVL n = (NodeAVL) node;

        if (value < n.data) n.left = insertRec(n.left, value);
        else if (value > n.data) n.right = insertRec(n.right, value);
        else throw new ItemDuplicated("Valor duplicado: " + value);

        n.height = 1 + Math.max(height(n.left), height(n.right));

        int balance = getBalance(n);

        // Rotaciones
        if (balance > 1 && value < n.left.data) return rotateRight(n); // LL
        if (balance < -1 && value > n.right.data) return rotateLeft(n); // RR
        if (balance > 1 && value > n.left.data) {
            n.left = rotateLeft((NodeAVL) n.left); // LR
            return rotateRight(n);
        }
        if (balance < -1 && value < n.right.data) {
            n.right = rotateRight((NodeAVL) n.right); // RL
            return rotateLeft(n);
        }

        return n;
    }

    private int height(NodeBST node) {
        return node == null ? 0 : ((NodeAVL) node).height;
    }

    private int getBalance(NodeAVL node) {
        return (node == null) ? 0 : height(node.left) - height(node.right);
    }

    private NodeAVL rotateRight(NodeAVL y) {
        NodeAVL x = (NodeAVL) y.left;
        NodeAVL T2 = (NodeAVL) x.right;

        x.right = y;
        y.left = T2;

        y.height = Math.max(height(y.left), height(y.right)) + 1;
        x.height = Math.max(height(x.left), height(x.right)) + 1;

        return x;
    }

    private NodeAVL rotateLeft(NodeAVL x) {
        NodeAVL y = (NodeAVL) x.right;
        NodeAVL T2 = (NodeAVL) y.left;

        y.left = x;
        x.right = T2;

        x.height = Math.max(height(x.left), height(x.right)) + 1;
        y.height = Math.max(height(y.left), height(y.right)) + 1;

        return y;
    }

    @Override
    public void insert(int value) throws ItemDuplicated {
        root = insertRec(root, value);
    }

    @Override
    public void preorder() {
        preorderRec(root);
        System.out.println();
    }
}
