public class Test2 {
    public static void main(String[] args) {
        AVLTree avl = new AVLTree();
        int[] rotaciones = {10, 20, 30}; // Provocará rotación izquierda (RR)

        try {
            for (int v : rotaciones) avl.insert(v);
        } catch (ItemDuplicated e) {
            System.out.println(e.getMessage());
        }

        System.out.println("\nRecorrido PreOrden tras inserciones RR:");
        avl.preorder();
    }
}