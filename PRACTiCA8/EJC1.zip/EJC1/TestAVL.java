public class TestAVL {
    public static void main(String[] args) {
        BSTree bst = new BSTree();
        AVLTree avl = new AVLTree();

        int[] valores = {30, 20, 10, 25, 40, 50};

        try {
            for (int v : valores) bst.insert(v);
            for (int v : valores) avl.insert(v);
        } catch (ItemDuplicated e) {
            System.out.println(e.getMessage());
        }

        System.out.println("Recorrido PreOrden del Árbol Binario de Búsqueda:");
        bst.preorder();

        System.out.println("\nRecorrido PreOrden del Árbol AVL:");
        avl.preorder();
    }
}