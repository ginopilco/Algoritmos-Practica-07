public class BSTree {
    protected NodeBST root;

    public BSTree() {
        root = null;
    }

    public void insert(int value) throws ItemDuplicated {
        root = insertRec(root, value);
    }

    protected NodeBST insertRec(NodeBST node, int value) throws ItemDuplicated {
        if (node == null) return new NodeBST(value);
        if (value < node.data) node.left = insertRec(node.left, value);
        else if (value > node.data) node.right = insertRec(node.right, value);
        else throw new ItemDuplicated("Valor duplicado: " + value);
        return node;
    }

    public void preorder() {
        preorderRec(root);
        System.out.println();
    }

    protected void preorderRec(NodeBST node) {
        if (node != null) {
            System.out.print(node.data + " -> ");
            preorderRec(node.left);
            preorderRec(node.right);
        }
    }
}