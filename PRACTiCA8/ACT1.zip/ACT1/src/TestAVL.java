public class TestAVL {
    public static void main(String[] args) {
        AVLTree<Integer> tree = new AVLTree<>();

        try {
            // Casos que generan rotaciones simples y dobles
            tree.insert(30); // sin rotación
            tree.insert(20); // sin rotación
            tree.insert(10); // RSR (rotación simple a la derecha)

            tree.insert(40); // sin rotación
            tree.insert(50); // RSL (rotación simple a la izquierda)

            tree.insert(5);  // sin rotación
            tree.insert(7);  // RDR (rotación doble a la derecha)

            tree.insert(60); // sin rotación
            tree.insert(55); // RDL (rotación doble a la izquierda)

            System.out.println("Inserciones completadas.");
        } catch (ItemDuplicated e) {
            System.out.println(e.getMessage());
        }
    }
}
