public class AVLTree<E extends Comparable<E>> extends BSTree<E> {
    private boolean height;

    @Override
    protected Node<E> insert(E x, Node<E> node) throws ItemDuplicated {
        NodeAVL<E> fat = (NodeAVL<E>) node;

        if (node == null) {
            this.height = true;
            return new NodeAVL<>(x);
        }

        int resC = x.compareTo(node.getData());
        if (resC == 0) {
            throw new ItemDuplicated(x + " ya se encuentra en el árbol...");
        }

        if (resC > 0) {
            fat.setRight(insert(x, node.getRight()));
            if (this.height) {
                switch (fat.bf) {
                    case -1:
                        fat.bf = 0;
                        this.height = false;
                        break;
                    case 0:
                        fat.bf = 1;
                        this.height = true;
                        break;
                    case 1:
                        fat = balanceToLeft(fat);
                        this.height = false;
                        break;
                }
            }
        } else {
            fat.setLeft(insert(x, node.getLeft()));
            if (this.height) {
                switch (fat.bf) {
                    case 1:
                        fat.bf = 0;
                        this.height = false;
                        break;
                    case 0:
                        fat.bf = -1;
                        this.height = true;
                        break;
                    case -1:
                        fat = balanceToRight(fat);
                        this.height = false;
                        break;
                }
            }
        }

        return fat;
    }

    private NodeAVL<E> balanceToLeft(NodeAVL<E> node) {
        NodeAVL<E> child = (NodeAVL<E>) node.getRight();
        switch (child.bf) {
            case 1:
                node.bf = 0;
                child.bf = 0;
                node = rotateSL(node);
                break;
            case -1:
                NodeAVL<E> grandChild = (NodeAVL<E>) child.getLeft();
                switch (grandChild.bf) {
                    case -1:
                        node.bf = 0;
                        child.bf = 1;
                        break;
                    case 0:
                        node.bf = 0;
                        child.bf = 0;
                        break;
                    case 1:
                        node.bf = 1;
                        child.bf = 0;
                        break;
                }
                grandChild.bf = 0;
                node.setRight(rotateSR(child));
                node = rotateSL(node);
                break;
        }
        return node;
    }

    private NodeAVL<E> balanceToRight(NodeAVL<E> node) {
        NodeAVL<E> child = (NodeAVL<E>) node.getLeft();
        switch (child.bf) {
            case -1:
                node.bf = 0;
                child.bf = 0;
                node = rotateSR(node);
                break;
            case 1:
                NodeAVL<E> grandChild = (NodeAVL<E>) child.getRight();
                switch (grandChild.bf) {
                    case 1:
                        node.bf = 0;
                        child.bf = -1;
                        break;
                    case 0:
                        node.bf = 0;
                        child.bf = 0;
                        break;
                    case -1:
                        node.bf = -1;
                        child.bf = 0;
                        break;
                }
                grandChild.bf = 0;
                node.setLeft(rotateSL(child));
                node = rotateSR(node);
                break;
        }
        return node;
    }

    private NodeAVL<E> rotateSL(NodeAVL<E> node) {
        NodeAVL<E> p = (NodeAVL<E>) node.getRight();
        node.setRight(p.getLeft());
        p.setLeft(node);
        return p;
    }

    private NodeAVL<E> rotateSR(NodeAVL<E> node) {
        NodeAVL<E> p = (NodeAVL<E>) node.getLeft();
        node.setLeft(p.getRight());
        p.setRight(node);
        return p;
    }
}
