package graph;

public class Main {
    public static void main(String[] args) {
        GraphListEdge graph = new GraphListEdge();

        graph.insertVertex("A");
        graph.insertVertex("B");
        graph.insertVertex("C");
        graph.insertVertex("D");

        graph.insertEdge("A", "B", 5);
        graph.insertEdge("A", "C", 3);
        graph.insertEdge("B", "D", 2);
        graph.insertEdge("C", "D", 4);

        System.out.println("Grafo:");
        graph.printGraph();

        System.out.println("\nRecorrido BFS desde A:");
        graph.bfs("A");

        System.out.println("\nRecorrido DFS desde A:");
        graph.dfs("A");
    }
}
