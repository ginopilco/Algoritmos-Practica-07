package graph;

import java.util.*;

public class GraphListEdge {
    private Map<VertexObj, List<EdgeObj>> adjList;

    public GraphListEdge() {
        adjList = new HashMap<>();
    }

    public void insertVertex(String name) {
        VertexObj v = new VertexObj(name);
        adjList.putIfAbsent(v, new ArrayList<>());
    }

    public void insertEdge(String from, String to, int weight) {
        VertexObj v1 = new VertexObj(from);
        VertexObj v2 = new VertexObj(to);
        insertVertex(from);
        insertVertex(to);
        adjList.get(v1).add(new EdgeObj(v1, v2, weight));
        adjList.get(v2).add(new EdgeObj(v2, v1, weight)); // undirected
    }

    public VertexObj searchVertex(String name) {
        return adjList.keySet().stream()
                .filter(v -> v.getName().equals(name))
                .findFirst()
                .orElse(null);
    }

    public EdgeObj searchEdge(String from, String to) {
        VertexObj v1 = searchVertex(from);
        VertexObj v2 = searchVertex(to);
        if (v1 == null || v2 == null) return null;
        for (EdgeObj edge : adjList.get(v1)) {
            if (edge.getTo().equals(v2)) return edge;
        }
        return null;
    }

    public void bfs(String startName) {
        VertexObj start = searchVertex(startName);
        if (start == null) return;

        Set<VertexObj> visited = new HashSet<>();
        Queue<VertexObj> queue = new LinkedList<>();
        visited.add(start);
        queue.add(start);

        while (!queue.isEmpty()) {
            VertexObj current = queue.poll();
            System.out.println("Visitando: " + current);
            for (EdgeObj edge : adjList.get(current)) {
                if (!visited.contains(edge.getTo())) {
                    visited.add(edge.getTo());
                    queue.add(edge.getTo());
                }
            }
        }
    }

    public void dfs(String startName) {
        VertexObj start = searchVertex(startName);
        if (start == null) return;
        Set<VertexObj> visited = new HashSet<>();
        dfsRecursive(start, visited);
    }

    private void dfsRecursive(VertexObj current, Set<VertexObj> visited) {
        visited.add(current);
        System.out.println("Visitando: " + current);
        for (EdgeObj edge : adjList.get(current)) {
            if (!visited.contains(edge.getTo())) {
                dfsRecursive(edge.getTo(), visited);
            }
        }
    }

    public void printGraph() {
        for (VertexObj v : adjList.keySet()) {
            System.out.println(v + " -> " + adjList.get(v));
        }
    }
} 