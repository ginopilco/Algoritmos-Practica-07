package graph;

public class EdgeObj {
    private VertexObj from;
    private VertexObj to;
    private int weight;

    public EdgeObj(VertexObj from, VertexObj to, int weight) {
        this.from = from;
        this.to = to;
        this.weight = weight;
    }

    public VertexObj getFrom() {
        return from;
    }

    public VertexObj getTo() {
        return to;
    }

    public int getWeight() {
        return weight;
    }

    @Override
    public String toString() {
        return from + " -> " + to + " (" + weight + ")";
    }
}
