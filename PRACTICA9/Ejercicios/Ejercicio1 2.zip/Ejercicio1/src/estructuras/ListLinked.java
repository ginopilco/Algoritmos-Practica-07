package estructuras;

public class ListLinked<E> {
    private Node<E> head;

    public ListLinked() {
        head = null;
    }

    public void addFirst(E element) {
        Node<E> newNode = new Node<>(element);
        newNode.setNext(head);
        head = newNode;
    }

    public void addLast(E element) {
        Node<E> newNode = new Node<>(element);
        if (head == null) {
            head = newNode;
        } else {
            Node<E> current = head;
            while (current.getNext() != null) {
                current = current.getNext();
            }
            current.setNext(newNode);
        }
    }

    public boolean contains(E element) {
        Node<E> current = head;
        while (current != null) {
            if (current.getData().equals(element)) {
                return true;
            }
            current = current.getNext();
        }
        return false;
    }

    public boolean isEmpty() {
        return head == null;
    }

    public void printList() {
        Node<E> current = head;
        while (current != null) {
            System.out.print(current.getData() + " -> ");
            current = current.getNext();
        }
        System.out.println("null");
    }

    public Node<E> getHead() {
        return head;
    }
}
