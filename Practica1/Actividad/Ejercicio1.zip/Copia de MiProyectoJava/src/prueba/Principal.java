package prueba;

import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // coordenadas del primer rectángulo
        System.out.println("Ingrese una esquina del 1er rectángulo: ");
        Coordenada c1Rect1 = new Coordenada(scanner.nextDouble(), scanner.nextDouble());
        System.out.println("Ingrese la esquina opuesta del 1er rectángulo: ");
        Coordenada c2Rect1 = new Coordenada(scanner.nextDouble(), scanner.nextDouble());
        
        // Creación del primer rectángulo
        Rectangulo rect1 = new Rectangulo(c1Rect1, c2Rect1);
        
        // coordenadas del segundo rectángulo
        System.out.println("Ingrese una esquina del 2do rectángulo: ");
        Coordenada c1Rect2 = new Coordenada(scanner.nextDouble(), scanner.nextDouble());
        System.out.println("Ingrese la esquina opuesta del 2do rectángulo: ");
        Coordenada c2Rect2 = new Coordenada(scanner.nextDouble(), scanner.nextDouble());
        
        // Creación del segundo rectángulo
        Rectangulo rect2 = new Rectangulo(c1Rect2, c2Rect2);
        
        // Mostrar información
        System.out.println("Rectangulo A = " + rect1.toString());
        System.out.println("Rectangulo B = " + rect2.toString());
        
        // Verificar relación entre los rectángulos
        if (Verificador.seSobreponen(rect1, rect2)) {
            System.out.println("Rectangulos A y B se sobreponen.");
            double area = Verificador.calcularAreaSobreposicion(rect1, rect2);
            System.out.println("Area de sobreposicion = " + area);
        } else if (Verificador.estanJuntos(rect1, rect2)) {
            System.out.println("Los rectángulos están juntos.");
        } else if (Verificador.sonDisjuntos(rect1, rect2)) {
            System.out.println("Los rectángulos son disjuntos.");
        }
    }
}
