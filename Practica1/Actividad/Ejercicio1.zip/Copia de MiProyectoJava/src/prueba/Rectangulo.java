package prueba;

public class Rectangulo {
    private Coordenada esquina1; // esquina inferior izquierda
    private Coordenada esquina2; // esquina superior derecha

    public Rectangulo(Coordenada c1, Coordenada c2) {
        // Garantizamos que esquina1 sea la inferior izquierda y esquina2 la superior derecha
        this.esquina1 = new Coordenada(Math.min(c1.getX(), c2.getX()), Math.min(c1.getY(), c2.getY()));
        this.esquina2 = new Coordenada(Math.max(c1.getX(), c2.getX()), Math.max(c1.getY(), c2.getY()));
    }

    public Coordenada getEsquina1() {
        return esquina1;
    }

    public Coordenada getEsquina2() {
        return esquina2;
    }

    public double calculoArea() {
        double longitud = Math.abs(esquina2.getX() - esquina1.getX());
        double altura = Math.abs(esquina2.getY() - esquina1.getY());
        return longitud * altura;
    }

    @Override
    public String toString() {
        return "[" + esquina1.toString() + "], [" + esquina2.toString() + "]";
    }
}
