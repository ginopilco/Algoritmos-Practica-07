package prueba;

public class Verificador {

    public static boolean seSobreponen(Rectangulo r1, Rectangulo r2) {
        // Verificar si uno está a la izquierda del otro
        if (r1.getEsquina2().getX() <= r2.getEsquina1().getX() || 
            r1.getEsquina1().getX() >= r2.getEsquina2().getX()) {
            return false;
        }
    
        // Verificar si uno está por encima o por debajo del otro
        if (r1.getEsquina2().getY() <= r2.getEsquina1().getY() || 
            r1.getEsquina1().getY() >= r2.getEsquina2().getY()) {
            return false;
        }
    
        return true; // Los rectángulos se sobreponen
    }

    public static double calcularAreaSobreposicion(Rectangulo r1, Rectangulo r2) {
        if (!seSobreponen(r1, r2)) {
            return 0;
        }
        
        // Calcular las coordenadas del área de sobreposición
        double xIzquierda = Math.max(r1.getEsquina1().getX(), r2.getEsquina1().getX());
        double xDerecha = Math.min(r1.getEsquina2().getX(), r2.getEsquina2().getX());
        double yInferior = Math.max(r1.getEsquina1().getY(), r2.getEsquina1().getY());
        double ySuperior = Math.min(r1.getEsquina2().getY(), r2.getEsquina2().getY());

        // Si las diferencias en las coordenadas no son positivas, no hay intersección
        if (xDerecha > xIzquierda && ySuperior > yInferior) {
            double area = Math.abs(xDerecha - xIzquierda) * Math.abs(ySuperior - yInferior);
            return area;
        } else {
            return 0; // No hay área de sobreposición
        }
    }
    
    public static boolean estanJuntos(Rectangulo r1, Rectangulo r2) {
        return tienenPuntoEnComunEnElBorde(r1, r2);
    }

    private static boolean tienenPuntoEnComunEnElBorde(Rectangulo r1, Rectangulo r2) {
        double izquierda1 = Math.min(r1.getEsquina1().getX(), r1.getEsquina2().getX());
        double derecha1 = Math.max(r1.getEsquina1().getX(), r1.getEsquina2().getX());
        double superior1 = Math.max(r1.getEsquina1().getY(), r1.getEsquina2().getY());
        double inferior1 = Math.min(r1.getEsquina1().getY(), r1.getEsquina2().getY());

        double izquierda2 = Math.min(r2.getEsquina1().getX(), r2.getEsquina2().getX());
        double derecha2 = Math.max(r2.getEsquina1().getX(), r2.getEsquina2().getX());
        double superior2 = Math.max(r2.getEsquina1().getY(), r2.getEsquina2().getY());
        double inferior2 = Math.min(r2.getEsquina1().getY(), r2.getEsquina2().getY());

        boolean compartenLadoVertical = (derecha1 == izquierda2 || izquierda1 == derecha2) && (inferior1 < superior2 && superior1 > inferior2);
        boolean compartenLadoHorizontal = (superior1 == inferior2 || inferior1 == superior2) && (izquierda1 < derecha2 && derecha1 > izquierda2);

        return compartenLadoVertical || compartenLadoHorizontal;
    }

    public static boolean sonDisjuntos(Rectangulo r1, Rectangulo r2) {
        return !seSobreponen(r1, r2) && !estanJuntos(r1, r2);
    }
}
