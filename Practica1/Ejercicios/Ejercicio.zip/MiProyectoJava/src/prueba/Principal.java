package prueba;

import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Crear el contenedor de rectángulos
        ContainerRect container = new ContainerRect(10);

        // Coordenadas del primer rectángulo
        System.out.println("Ingrese las coordenadas de la esquina inferior izquierda del primer rectángulo (x y):");
        Coordenada c1Rect1 = new Coordenada(scanner.nextDouble(), scanner.nextDouble());
        System.out.println("Ingrese las coordenadas de la esquina superior derecha del primer rectángulo (x y):");
        Coordenada c2Rect1 = new Coordenada(scanner.nextDouble(), scanner.nextDouble());

        // Ajustar las coordenadas para asegurar que c1Rect1 sea la esquina inferior izquierda y c2Rect1 la superior derecha
        if (c1Rect1.getX() > c2Rect1.getX()) {
            double tempX = c1Rect1.getX();
            c1Rect1.setX(c2Rect1.getX());
            c2Rect1.setX(tempX);
        }
        if (c1Rect1.getY() > c2Rect1.getY()) {
            double tempY = c1Rect1.getY();
            c1Rect1.setY(c2Rect1.getY());
            c2Rect1.setY(tempY);
        }

        // Creación del primer rectángulo
        Rectangulo rect1 = new Rectangulo(c1Rect1, c2Rect1);

        // Coordenadas del segundo rectángulo
        System.out.println("Ingrese las coordenadas de la esquina inferior izquierda del segundo rectángulo (x y):");
        Coordenada c1Rect2 = new Coordenada(scanner.nextDouble(), scanner.nextDouble());
        System.out.println("Ingrese las coordenadas de la esquina superior derecha del segundo rectángulo (x y):");
        Coordenada c2Rect2 = new Coordenada(scanner.nextDouble(), scanner.nextDouble());

        // Ajustar las coordenadas para asegurar que c1Rect2 sea la esquina inferior izquierda y c2Rect2 la superior derecha
        if (c1Rect2.getX() > c2Rect2.getX()) {
            double tempX = c1Rect2.getX();
            c1Rect2.setX(c2Rect2.getX());
            c2Rect2.setX(tempX);
        }
        if (c1Rect2.getY() > c2Rect2.getY()) {
            double tempY = c1Rect2.getY();
            c1Rect2.setY(c2Rect2.getY());
            c2Rect2.setY(tempY);
        }

        // Creación del segundo rectángulo
        Rectangulo rect2 = new Rectangulo(c1Rect2, c2Rect2);

        // Ahora agregas los rectángulos al contenedor
        container.addRectangulo(rect1);
        container.addRectangulo(rect2);

        // Mostrar el contenido del contenedor
        System.out.println(container);
    }
}
