package prueba;

public class Rectangulo {
    private Coordenada esquina1;
    private Coordenada esquina2;

    public Rectangulo(Coordenada c1, Coordenada c2) {
        this.esquina1 = c1;
        this.esquina2 = c2;
    }

    public Coordenada getEsquina1() {
        return esquina1;
    }

    public Coordenada getEsquina2() {
        return esquina2;
    }

    // Calcula el área del rectángulo
    public double calcularArea() {
        double longitud = Math.abs(esquina2.getX() - esquina1.getX());
        double altura = Math.abs(esquina2.getY() - esquina1.getY());
        return longitud * altura;
    }

    // Calcula la distancia euclidiana entre las dos esquinas del rectángulo
    public double calcularDistancia() {
        double dx = esquina2.getX() - esquina1.getX();
        double dy = esquina2.getY() - esquina1.getY();
        return Math.sqrt(dx * dx + dy * dy);
    }

    @Override
    public String toString() {
        return  esquina1.toString() + ","  + esquina2.toString();
    }
}
