package prueba;

public class ContainerRect {
    private Rectangulo[] rectangulos;
    private double[] distancias;
    private double[] areas;
    private int n; // Máximo número de rectángulos
    private static int numRec = 0; // Contador de rectángulos almacenados

    public ContainerRect(int maxRectangulos) {
        this.n = maxRectangulos;
        this.rectangulos = new Rectangulo[n];
        this.distancias = new double[n];
        this.areas = new double[n];
    }

    // Método para agregar un rectángulo al contenedor
    public void addRectangulo(Rectangulo rect) {
        if (numRec < n) {
            rectangulos[numRec] = rect;
            distancias[numRec] = rect.calcularDistancia();
            areas[numRec] = rect.calcularArea();
            numRec++;
        } else {
            System.out.println("No se puede agregar más rectángulos. El contenedor está lleno.");
        }
    }

    // Método para mostrar los rectángulos, sus distancias y áreas
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Rectangulo\tCoordenadas\tDistancia\tArea\n");
        for (int i = 0; i < numRec; i++) {
            sb.append(i + 1).append(":\t")
              .append(rectangulos[i].toString()).append("\t")
              .append(String.format("%.3f", distancias[i])).append("\t\t")
              .append(String.format("%.2f", areas[i])).append("\n");
        }
        return sb.toString();
    }
}
