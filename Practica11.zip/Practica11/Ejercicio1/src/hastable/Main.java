package hastable;

public class Main {
    public static void main(String[] args) {
        HashTable table = new HashTable(7); // Tamaño de tabla = 7
        int[] values = {3, 10, 17, 24};

        for (int value : values) {
            table.insert(value);
        }

        table.display();
    }
}
