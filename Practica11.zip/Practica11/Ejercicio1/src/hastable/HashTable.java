package hastable;

import java.util.LinkedList;

public class HashTable {
    private LinkedList<Integer>[] table;

    // Constructor
    @SuppressWarnings("unchecked")
    public HashTable(int size) {
        table = new LinkedList[size];
        for (int i = 0; i < size; i++) {
            table[i] = new LinkedList<>();
        }
    }

    // Función hash
    private int hash(int key) {
        return key % table.length;
    }

    // Insertar usando hash abierto (encadenamiento)
    public void insert(int key) {
        int index = hash(key);
        table[index].add(key);
    }

    // Mostrar la tabla
    public void display() {
        System.out.println("Tabla Hash con encadenamiento:");
        for (int i = 0; i < table.length; i++) {
            System.out.print("[" + i + "]: ");
            if (table[i].isEmpty()) {
                System.out.println("vacío");
            } else {
                System.out.println(table[i]);
            }
        }
    }
}
