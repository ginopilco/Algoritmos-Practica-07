package hash;

/**
 * Implementación de una tabla hash usando hash cerrado (sondeo lineal).
 */
public class HashC {
    private static class Element {
        Register register;
        boolean isAvailable;

        public Element() {
            this.register = null;
            this.isAvailable = true;
        }
    }

    private Element[] table;
    private int size;

    public HashC(int size) {
        this.size = size;
        table = new Element[size];
        for (int i = 0; i < size; i++) {
            table[i] = new Element();
        }
    }

    private int hash(int key) {
        return key % size;
    }

    public void insert(Register reg) {
        int index = hash(reg.getKey());
        int originalIndex = index;
        boolean inserted = false;

        for (int i = 0; i < size; i++) {
            if (table[index].isAvailable) {
                table[index].register = reg;
                table[index].isAvailable = false;
                inserted = true;
                break;
            } else {
                index = (originalIndex + i + 1) % size;//pasa al siguiente 
            }
        }

        if (!inserted) {
            System.out.println("Error: La tabla hash está llena. No se pudo insertar " + reg);
        }
    }

    public Register search(int key) {
        int index = hash(key);
        for (int i = 0; i < size; i++) {
            int currentIndex = (index + i) % size;
            Element e = table[currentIndex];

            if (!e.isAvailable && e.register.getKey() == key) {
                return e.register;
            }

            if (e.isAvailable && e.register == null) {
                break; // Nunca hubo un registro aquí
            }
        }
        return null;
    }

    public void delete(int key) {
        int index = hash(key);
        for (int i = 0; i < size; i++) {
            int currentIndex = (index + i) % size;
            Element e = table[currentIndex];

            if (!e.isAvailable && e.register.getKey() == key) {
                e.isAvailable = true; // Eliminación lógica
                System.out.println("Registro con clave " + key + " eliminado.");
                return;
            }

            if (e.isAvailable && e.register == null) {
                break;
            }
        }

        System.out.println("No se encontró el registro con clave " + key + " para eliminar.");
    }

    public void printTable() {
        System.out.println("\nTabla actual hash ");
        for (int i = 0; i < size; i++) {
            System.out.print("cuadro" + i + ": ");
            if (!table[i].isAvailable) {
                System.out.println(table[i].register);
            } else {
                System.out.println("vacío");
            }
        }
    }
}
