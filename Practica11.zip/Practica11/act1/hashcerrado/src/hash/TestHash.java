package hash;

/**
 * Clase de prueba para la tabla hash cerrada con sondeo lineal.
 */
public class TestHash {
    public static void main(String[] args) {
        HashC tabla = new HashC(29); // Tamaño fijo recomendado (puede cambiarse)

        Register[] registros = {
            new Register(34, "Ana"),
            new Register(3, "Luis"),
            new Register(7, "Carlos"),
            new Register(30, "Elena"),
            new Register(11, "María"),
            new Register(8, "Pedro"),
            new Register(7, "Camila"),     // Clave repetida
            new Register(23, "José"),
            new Register(41, "Lucía"),
            new Register(16, "Marco"),
            new Register(34, "Sandra")     // Clave repetida
        };

        for (Register reg : registros) {
            tabla.insert(reg);
        }

        tabla.printTable();

        // Eliminar clave 30
        tabla.delete(30);
        tabla.printTable();

        // Buscar clave 23
        Register resultado = tabla.search(23);
        System.out.println("\nResultado de búsqueda para clave 23: " +
            (resultado != null ? resultado : "No encontrado"));
    }
}
