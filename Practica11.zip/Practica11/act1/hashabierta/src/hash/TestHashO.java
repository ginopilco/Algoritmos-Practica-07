package hash;

/**
 * Clase de prueba para la tabla hash abierta (con encadenamiento).
 */
public class TestHashO {
    public static void main(String[] args) {
        HashO tabla = new HashO(12); // Tamaño de la tabla hash

        Register[] registros = {
            new Register(10, "Luis"),
            new Register(3, "Ana"),
            new Register(17, "Pedro"),   // 17 % 7 = 3 (colisión con 3)
            new Register(24, "Elena"),   // 24 % 7 = 3 (otra colisión)
            new Register(18, "Carlos"),
            new Register(10, "María")    // Clave repetida
        };

        for (Register reg : registros) {
            tabla.insert(reg);
        }

        tabla.printTable();

        // Buscar un registro
        Register encontrado = tabla.search(17);
        System.out.println("\nBúsqueda clave 17: " + (encontrado != null ? encontrado : "No encontrado"));

        // Eliminar un registro
        tabla.delete(3);
        tabla.printTable();
    }
}
