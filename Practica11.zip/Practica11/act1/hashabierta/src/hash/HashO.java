package hash;

import java.util.LinkedList;

/**
 * Implementación de una tabla hash con encadenamiento (listas enlazadas).
 */
public class HashO {
    private LinkedList<Register>[] table;
    private int size;

    // Constructor: inicializa cada posición con una lista vacía
    @SuppressWarnings("unchecked")
    public HashO(int size) {
        this.size = size;
        this.table = new LinkedList[size];
        for (int i = 0; i < size; i++) {
            table[i] = new LinkedList<>();
        }
    }

    // Función hash
    private int hash(int key) {
        return key % size;
    }

    // Inserta un registro en la lista correspondiente
    public void insert(Register reg) {
        int index = hash(reg.getKey());
        table[index].add(reg); //agrega a la misma pocicion
    }

    // Busca un registro por clave
    public Register search(int key) {
        int index = hash(key);
        for (Register reg : table[index]) {
            if (reg.getKey() == key) {
                return reg;
            }
        }
        return null;
    }

    // Elimina un registro por clave
    public void delete(int key) {
        int index = hash(key);
        for (Register reg : table[index]) {
            if (reg.getKey() == key) {
                table[index].remove(reg);
                System.out.println("Registro con clave " + key + " eliminado.");
                return;
            }
        }
        System.out.println("Registro con clave " + key + " no encontrado.");
    }

    // Imprime el estado de la tabla hash
    public void printTable() {
        System.out.println("\n tabla actual hash abierta ");
        for (int i = 0; i < size; i++) {
            System.out.print("cuadro " + i + ": ");
            if (table[i].isEmpty()) {
                System.out.println("vacío");
            } else {
                for (Register reg : table[i]) {
                    System.out.print(reg + " ");
                }
                System.out.println();
            }
        }
    }
}
