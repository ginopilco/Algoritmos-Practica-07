package hashtable;

public class Main {
    public static void main(String[] args) {
        HashTable table = new HashTable(6);
        int[] values = {12, 18, 24, 30};

        for (int value : values) {
            table.insert(value);
        }

        table.display();
    }
}
