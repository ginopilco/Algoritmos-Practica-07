package hashtable;

public class HashTable {
    private Integer[] table;

    public HashTable(int size) {
        table = new Integer[size];
    }

    private int hash(int key) {
        return key % table.length;
    }

    public void insert(int key) {
        int index = hash(key);
        int startIndex = index;

        while (table[index] != null) {
            System.out.println("Colisión al insertar " + key + " en índice " + index);
            index = (index + 1) % table.length;
            if (index == startIndex) {
                System.out.println("Tabla llena. No se pudo insertar " + key);
                return;
            }
        }
        table[index] = key;
        System.out.println("Insertado " + key + " en índice " + index);
    }

    public void display() {
        System.out.println("\nTabla Hash (sondeo lineal):");
        for (int i = 0; i < table.length; i++) {
            System.out.println("[" + i + "] = " + (table[i] != null ? table[i] : "vacío"));
        }
    }
}
