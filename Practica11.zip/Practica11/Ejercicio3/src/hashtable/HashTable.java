package hashtable;

import java.util.LinkedList;
//hash 
public class HashTable {

    private static class Pair {
        int key;
        String value;

        public Pair(int key, String value) {
            this.key = key;
            this.value = value;
        }
    }
//lista enlazadas coliciones 
    private LinkedList<Pair>[] table;

    @SuppressWarnings("unchecked")
    public HashTable(int size) {
        table = new LinkedList[size];//tamaño
        for (int i = 0; i < size; i++) {
            table[i] = new LinkedList<>();//inicia basio posicion 
        }
    }
//distribucion 
    private int hash(int key) {
        return key % table.length;
    }
//inserta 
    public void insert(int key, String value) {
        int index = hash(key);
        table[index].add(new Pair(key, value));
        System.out.println("Insertado (" + key + ", " + value + ") en índice " + index);
    }
    //busca 
    public String search(int key) {
        int index = hash(key);
        for (Pair pair : table[index]) {
            if (pair.key == key) {
                return pair.value;
            }
        }
        return null; // Clave no encontrada
    }
}
