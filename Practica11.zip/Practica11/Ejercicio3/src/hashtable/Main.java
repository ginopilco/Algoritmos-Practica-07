package hashtable;

public class Main {
    public static void main(String[] args) {
        HashTable table = new HashTable(5);

        // Inserciones
        table.insert(10, "Juan");
        table.insert(15, "Ana");
        table.insert(20, "Luis");
        table.insert(25, "Rosa");

        // Búsquedas
        System.out.println("\nBuscar clave 20:");
        String result1 = table.search(20);
        System.out.println(result1 != null ? "Encontrado: " + result1 : "Clave no encontrada");

        System.out.println("\nBuscar clave 30:");
        String result2 = table.search(30);
        System.out.println(result2 != null ? "Encontrado: " + result2 : "Clave no encontrada");
    }
}
