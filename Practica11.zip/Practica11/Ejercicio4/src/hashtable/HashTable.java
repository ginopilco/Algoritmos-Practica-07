package hashtable;

public class HashTable {

    // Celda
    private static class Slot {
        Integer key;       // almacenada
        boolean isDeleted; // Marca si fue eliminada lógicamente

        Slot(Integer key) {
            this.key = key;
            this.isDeleted = false; // Por defecto, no está eliminada
        }
    }

    private Slot[] table; // Arreglo representa la tabla hash

    //  inicializa la tabla con el tamaño dado
    public HashTable(int size) {
        table = new Slot[size];
    }

    // alcula la posición base usando módulo
    private int hash(int key) {
        return key % table.length;
    }

    // Método para insertar una clave en la tabla hash
    public void insert(int key) {
        int index = hash(key);     
        int start = index;         

        do {
            // Si la celda está vacía 
            if (table[index] == null || table[index].isDeleted) {
                table[index] = new Slot(key); // Inserta nuevo celda
                System.out.println("Insertado " + key + " en índice " + index);
                return;
            }

            // Si hay colisión, recorre
            index = (index + 1) % table.length;
        } while (index != start); // Terminamos si damos toda la vuelta

        System.out.println("Tabla llena. No se pudo insertar " + key);
    }

    // eliminacion logica
    public void delete(int key) {
        int index = hash(key);
        int start = index;

        do {
            // Si encontramos una celda vacía, la clave no está
            if (table[index] == null) return;

            // Si encontramos la clave y no está eliminada, la marcamos como eliminada
            if (!table[index].isDeleted && table[index].key == key) {
                table[index].isDeleted = true; // Eliminación lógica
                System.out.println("Clave " + key + " eliminada lógicamente en índice " + index);
                return;
            }

            // sondeo lineal
            index = (index + 1) % table.length;
        } while (index != start); //si damos toda la vuelta
    }

    // busca
    public boolean search(int key) {
        int index = hash(key);
        int start = index;

        do {
            // celda basia 
            if (table[index] == null) return false;

            // Si encontramos la clave y no está eliminada, devolvemos true
            if (!table[index].isDeleted && table[index].key == key) {
                return true;
            }

            index = (index + 1) % table.length;
        } while (index != start); // Terminamos si damos toda la vuelta

        // No se encontró la clave
        return false;
    }

    // Muestra el estado actual de la tabla
    public void display() {
        System.out.println("\nTabla Hash:");
        for (int i = 0; i < table.length; i++) {
            if (table[i] == null) {
                System.out.println("[" + i + "] = vacío");
            } else if (table[i].isDeleted) {
                System.out.println("[" + i + "] = eliminado");
            } else {
                System.out.println("[" + i + "] = " + table[i].key);
            }
        }
    }
}
