package hashtable;

public class Main {
    public static void main(String[] args) {
        HashTable table = new HashTable(7);

        // Inserción
        table.insert(5);
        table.insert(12);
        table.insert(19);

        table.display();

        // Eliminación lógica
        System.out.println("\nEliminando clave 12...");
        table.delete(12);

        table.display();

        // Búsqueda de 19 después de eliminar 12
        System.out.println("\nBuscar clave 19:");
        boolean found = table.search(19);
        System.out.println(found ? "Clave 19 encontrada" : "Clave 19 NO encontrada");

        // Búsqueda de 12 (ya eliminada)
        System.out.println("Buscar clave 12:");
        boolean found12 = table.search(12);
        System.out.println(found12 ? "Clave 12 encontrada" : "Clave 12 NO encontrada");
    }
}
