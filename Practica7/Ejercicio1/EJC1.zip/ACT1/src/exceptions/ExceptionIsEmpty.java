package exceptions;

public class ExceptionIsEmpty extends RuntimeException {
    public ExceptionIsEmpty(String msg) {
        super(msg);
    }
}
