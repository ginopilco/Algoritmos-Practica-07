package bstreelinklistinterfgeneric;

import java.util.LinkedList;
import java.util.Queue;
import exceptions.ExceptionIsEmpty;

public class LinkedBST<T extends Comparable<T>> {

    protected static class Node<E> {
        E data;
        Node<E> left, right;

        Node(E data) {
            this.data = data;
            left = right = null;
        }
    }

    protected Node<T> root;

    public LinkedBST() {
        root = null;
    }

    public void insert(T value) {
        root = insertRec(root, value);
    }

    private Node<T> insertRec(Node<T> node, T value) {
        if (node == null)
            return new Node<>(value);
        if (value.compareTo(node.data) < 0)
            node.left = insertRec(node.left, value);
        else if (value.compareTo(node.data) > 0)
            node.right = insertRec(node.right, value);
        return node;
    }

    // 1.a Eliminar todos los nodos
    public void destroyNodes() throws ExceptionIsEmpty {
        if (root == null)
            throw new ExceptionIsEmpty("El árbol está vacío.");
        root = null;
    }

    // 1.b Contar nodos no hojas
    public int countAllNodes() {
        return countAllNodes(root);
    }

    private int countAllNodes(Node<T> node) {
        if (node == null || (node.left == null && node.right == null)) return 0;
        return 1 + countAllNodes(node.left) + countAllNodes(node.right);
    }

    // 1.c Alias
    public int countNodes() {
        return countAllNodes();
    }

    // 1.d Altura iterativa de subárbol con raíz x
    public int height(T x) {
        Node<T> node = root;
        while (node != null) {
            int cmp = x.compareTo(node.data);
            if (cmp == 0) break;
            node = (cmp < 0) ? node.left : node.right;
        }
        if (node == null) return -1;

        Queue<Node<T>> queue = new LinkedList<>();
        queue.add(node);
        int height = -1;
        while (!queue.isEmpty()) {
            int size = queue.size();
            height++;
            for (int i = 0; i < size; i++) {
                Node<T> current = queue.poll();
                if (current.left != null) queue.add(current.left);
                if (current.right != null) queue.add(current.right);
            }
        }
        return height;
    }

    // 1.e Amplitud o número de nodos en cierto nivel
    public int amplitude(int level) {
        if (root == null) return 0;
        Queue<Node<T>> queue = new LinkedList<>();
        queue.add(root);
        int currentLevel = 0;
        while (!queue.isEmpty()) {
            int size = queue.size();
            if (currentLevel == level) return size;
            for (int i = 0; i < size; i++) {
                Node<T> node = queue.poll();
                if (node.left != null) queue.add(node.left);
                if (node.right != null) queue.add(node.right);
            }
            currentLevel++;
        }
        return 0;
    }

    // 2.a Área del árbol (hojas * altura)
    public int areaBST() {
        if (root == null) return 0;

        int leaves = 0;
        int height = -1;

        Queue<Node<T>> queue = new LinkedList<>();
        queue.add(root);

        while (!queue.isEmpty()) {
            int size = queue.size();
            height++;
            for (int i = 0; i < size; i++) {
                Node<T> node = queue.poll();
                if (node.left == null && node.right == null)
                    leaves++;
                if (node.left != null) queue.add(node.left);
                if (node.right != null) queue.add(node.right);
            }
        }

        return leaves * height;
    }

    // 2.b Dibujar el árbol
    public void drawBST() {
        drawBST(root, "", true);
    }

    private void drawBST(Node<T> node, String prefix, boolean isTail) {
        if (node == null) return;
        System.out.println(prefix + (isTail ? "└── " : "├── ") + node.data);
        if (node.left != null || node.right != null) {
            if (node.left != null)
                drawBST(node.left, prefix + (isTail ? "    " : "│   "), node.right == null);
            if (node.right != null)
                drawBST(node.right, prefix + (isTail ? "    " : "│   "), true);
        }
    }

    // 3. Formato sangría (parenthesize)
    public void parenthesize() {
        parenthesizeRec(root, 0);
    }

    private void parenthesizeRec(Node<T> node, int level) {
        if (node == null) return;

        for (int i = 0; i < level; i++)
            System.out.print("  ");

        System.out.println(node.data + " (");
        parenthesizeRec(node.left, level + 1);
        parenthesizeRec(node.right, level + 1);

        for (int i = 0; i < level; i++)
            System.out.print("  ");
        System.out.println(")");
    }
}
