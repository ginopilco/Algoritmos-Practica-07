package test;

import bstreelinklistinterfgeneric.LinkedBST;
import java.util.Scanner;

public class TestBST {

    public static void main(String[] args) {
        LinkedBST<Integer> tree1 = new LinkedBST<>();
        tree1.insert(50);
        tree1.insert(30);
        tree1.insert(70);
        tree1.insert(20);
        tree1.insert(40);
        tree1.insert(60);
        tree1.insert(80);

        LinkedBST<Integer> tree2 = new LinkedBST<>();
        tree2.insert(100);
        tree2.insert(90);
        tree2.insert(110);
        tree2.insert(95);
        tree2.insert(105);
        tree2.insert(115);
        tree2.insert(85);

        System.out.println("Área Árbol 1: " + tree1.areaBST());
        System.out.println("Área Árbol 2: " + tree2.areaBST());
        System.out.println("¿Misma área?: " + sameArea(tree1, tree2));

        System.out.println("\nDibujo del árbol 1:");
        tree1.drawBST();

        System.out.println("\nFormato sangría:");
        tree1.parenthesize();
    }

    public static boolean sameArea(LinkedBST<Integer> a, LinkedBST<Integer> b) {
        return a.areaBST() == b.areaBST();
    }
}
