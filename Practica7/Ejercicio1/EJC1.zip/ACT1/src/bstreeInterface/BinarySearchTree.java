package bstreeInterface;

public interface BinarySearchTree<E extends Comparable<E>> {
    void insert(E value);
    boolean search(E value);
    void delete(E value);

    String inOrderTraversal();
    String preOrderTraversal();
    String postOrderTraversal();
}
