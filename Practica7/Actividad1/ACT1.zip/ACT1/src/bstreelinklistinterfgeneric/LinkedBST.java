package bstreelinklistinterfgeneric;

public class LinkedBST<E extends Comparable<E>> {

    // Nodo interno
    class Node {
        E data;
        Node left, right;

        Node(E data) {
            this.data = data;
            left = right = null;
        }
    }

    private Node root;

    public LinkedBST() {
        root = null;
    }

    // Inserta un nuevo dato
    public void insert(E data) {
        root = insert(root, data);
    }

    private Node insert(Node node, E data) {
        if (node == null) return new Node(data);
        int cmp = data.compareTo(node.data);
        if (cmp < 0) node.left = insert(node.left, data);
        else if (cmp > 0) node.right = insert(node.right, data);
        // Si es igual no inserta (o manejar duplicados)
        return node;
    }

    // Buscar dato
    public boolean search(E data) {
        return search(root, data);
    }

    private boolean search(Node node, E data) {
        if (node == null) return false;
        int cmp = data.compareTo(node.data);
        if (cmp == 0) return true;
        else if (cmp < 0) return search(node.left, data);
        else return search(node.right, data);
    }

    // Recorridos públicos sin parámetros
    public String inOrder() {
        StringBuilder sb = new StringBuilder();
        inOrder(root, sb);
        return sb.toString();
    }

    public String preOrder() {
        StringBuilder sb = new StringBuilder();
        preOrder(root, sb);
        return sb.toString();
    }

    public String postOrder() {
        StringBuilder sb = new StringBuilder();
        postOrder(root, sb);
        return sb.toString();
    }

    // Recorridos recursivos
    private void inOrder(Node node, StringBuilder sb) {
        if (node == null) return;
        inOrder(node.left, sb);
        sb.append(node.data).append(" ");
        inOrder(node.right, sb);
    }

    private void preOrder(Node node, StringBuilder sb) {
        if (node == null) return;
        sb.append(node.data).append(" ");
        preOrder(node.left, sb);
        preOrder(node.right, sb);
    }

    private void postOrder(Node node, StringBuilder sb) {
        if (node == null) return;
        postOrder(node.left, sb);
        postOrder(node.right, sb);
        sb.append(node.data).append(" ");
    }

    // Eliminar nodo (simplificado)
    public void delete(E data) {
        root = delete(root, data);
    }

    private Node delete(Node node, E data) {
        if (node == null) return null;
        int cmp = data.compareTo(node.data);
        if (cmp < 0) node.left = delete(node.left, data);
        else if (cmp > 0) node.right = delete(node.right, data);
        else {
            // Caso con 1 o 0 hijos
            if (node.left == null) return node.right;
            if (node.right == null) return node.left;

            // Caso con 2 hijos: buscar sucesor mínimo en subárbol derecho
            Node minNode = findMin(node.right);
            node.data = minNode.data;
            node.right = delete(node.right, minNode.data);
        }
        return node;
    }

    private Node findMin(Node node) {
        while (node.left != null) node = node.left;
        return node;
    }
}
