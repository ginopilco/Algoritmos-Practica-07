package exceptions;

public class ItemNotFound extends RuntimeException {
    public ItemNotFound(String msg) {
        super(msg);
    }
}
