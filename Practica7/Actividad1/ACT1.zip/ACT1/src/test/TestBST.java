package test;

import bstreelinklistinterfgeneric.LinkedBST;
import java.util.Scanner;

public class TestBST {

    public static void main(String[] args) {
        LinkedBST<Integer> bst = new LinkedBST<>();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Menú de Árbol BST ---");
            System.out.println("1. Insertar");
            System.out.println("2. Buscar");
            System.out.println("3. Eliminar");
            System.out.println("4. Mostrar recorridos");
            System.out.println("5. Salir");
            System.out.print("Opción: ");

            int op = sc.nextInt();
            switch (op) {
                case 1:
                    System.out.print("Ingrese valor a insertar: ");
                    int valInsert = sc.nextInt();
                    bst.insert(valInsert);
                    System.out.println("Insertado: " + valInsert);
                    break;

                case 2:
                    System.out.print("Ingrese valor a buscar: ");
                    int valSearch = sc.nextInt();
                    boolean found = bst.search(valSearch);
                    System.out.println("¿Existe " + valSearch + "? " + found);
                    break;

                case 3:
                    System.out.print("Ingrese valor a eliminar: ");
                    int valDelete = sc.nextInt();
                    bst.delete(valDelete);
                    System.out.println("Eliminado: " + valDelete);
                    break;

                case 4:
                    System.out.println("Recorrido InOrden: " + bst.inOrder());
                    System.out.println("Recorrido PreOrden: " + bst.preOrder());
                    System.out.println("Recorrido PostOrden: " + bst.postOrder());
                    break;

                case 5:
                    System.out.println("Saliendo...");
                    sc.close();
                    return;

                default:
                    System.out.println("Opción inválida.");
            }
        }
    }
}
