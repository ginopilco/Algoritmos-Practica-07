public class viajemasbarato {

    public static double[][] calcularCostosMinimos(double[][] T) {
        int n = T.length;
        double[][] C = new double[n][n];

        // Inicializar la matriz C con infinito
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i == j) {
                    C[i][j] = 0;
                } else {
                    C[i][j] = Double.POSITIVE_INFINITY;
                }
            }
        }

        // Programación dinámica
        for (int longitud = 1; longitud < n; longitud++) {
            for (int i = 0; i < n - longitud; i++) {
                int j = i + longitud;
                C[i][j] = T[i][j]; // costo directo
                for (int k = i + 1; k < j; k++) {
                    C[i][j] = Math.min(C[i][j], T[i][k] + C[k][j]);
                }
            }
        }

        return C;
    }

    // Método para imprimir matrices
    public static void imprimirMatriz(double[][] matriz) {
        for (double[] fila : matriz) {
            for (double valor : fila) {
                if (valor == Double.POSITIVE_INFINITY) {
                    System.out.print("INF ");
                } else {
                    System.out.print(valor + " ");
                }
            }
            System.out.println();
        }
    }

    // Ejemplo de uso
    public static void main(String[] args) {
        double INF = Double.POSITIVE_INFINITY;
        double[][] T = {
            {0, 2, 9, INF},
            {0, 0, 6, 4},
            {0, 0, 0, 3},
            {0, 0, 0, 0}
        };

        double[][] C = calcularCostosMinimos(T);

        System.out.println("Matriz de costos mínimos:");
        imprimirMatriz(C);
    }
}
