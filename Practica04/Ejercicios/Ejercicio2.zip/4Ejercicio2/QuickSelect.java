import java.util.Random;

public class QuickSelect {

    // Función para particionar el arreglo alrededor de un pivote
    public static int partition(int[] arr, int low, int high) {
        int pivot = arr[high];  // Elegimos el último elemento como pivote
        int i = low - 1;  // El índice del menor elemento

        for (int j = low; j < high; j++) {
            if (arr[j] <= pivot) {
                i++;
                // Intercambiamos arr[i] y arr[j]
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        // Colocamos el pivote en su posición correcta
        int temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;

        return i + 1;  // Retornamos la posición del pivote
    }

    // Función recursiva para realizar el QuickSelect
    public static int quickSelect(int[] arr, int low, int high, int k) {
        if (low <= high) {
            // Elegimos un pivote aleatorio
            Random rand = new Random();
            int pivotIndex = rand.nextInt(high - low + 1) + low;
            // Movemos el pivote al final
            int temp = arr[pivotIndex];
            arr[pivotIndex] = arr[high];
            arr[high] = temp;

            // Particionamos el arreglo
            int pivotPos = partition(arr, low, high);

            if (pivotPos == k) {
                return arr[pivotPos];  // Si encontramos el k-ésimo elemento
            } else if (pivotPos < k) {
                // Si el pivote está antes del k-ésimo elemento, buscamos en la parte derecha
                return quickSelect(arr, pivotPos + 1, high, k);
            } else {
                // Si el pivote está después del k-ésimo elemento, buscamos en la parte izquierda
                return quickSelect(arr, low, pivotPos - 1, k);
            }
        }
        return -1;  // Si no se encuentra el elemento
    }

    // Función principal para encontrar el k-ésimo elemento más pequeño
    public static int findKthSmallest(int[] arr, int k) {
        return quickSelect(arr, 0, arr.length - 1, k - 1);  // Restamos 1 porque el índice es 0-based
    }

    public static void main(String[] args) {
        // Pruebas
        int[] arr1 = {4, 2, 7, 10, 4, 17};
        System.out.println(findKthSmallest(arr1, 3));  // 4

        int[] arr2 = {4, 2, 7, 10, 4, 1, 6};
        System.out.println(findKthSmallest(arr2, 5));  // 6

        int[] arr3 = {4, 2, 7, 1, 4, 6};
        System.out.println(findKthSmallest(arr3, 1));  // 1

        int[] arr4 = {9, 2, 7, 1, 7};
        System.out.println(findKthSmallest(arr4, 4));  // 7
    }
}
