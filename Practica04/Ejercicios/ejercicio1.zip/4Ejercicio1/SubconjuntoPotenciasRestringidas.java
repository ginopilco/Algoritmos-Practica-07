import java.util.*;

public class SubconjuntoPotenciasRestringidas {

    static boolean esPotenciaDe2(int n) {
        return n > 0 && (n & (n - 1)) == 0;
    }

    static boolean puedeFormarSuma(List<Integer> arreglo, int objetivo) {
        List<Integer> obligatorios = new ArrayList<>();
        List<Integer> candidatos = new ArrayList<>();

        for (int i = 0; i < arreglo.size(); i++) {
            int actual = arreglo.get(i);

            if (esPotenciaDe2(actual)) {
                obligatorios.add(actual); // deben incluirse sí o sí
            } else if (actual % 5 == 0 && i + 1 < arreglo.size() && arreglo.get(i + 1) % 2 == 1) {
                continue; // no se puede incluir
            } else {
                candidatos.add(actual); // se puede considerar opcionalmente
            }
        }

        int sumaObligatoria = obligatorios.stream().mapToInt(Integer::intValue).sum();
        int nuevoObjetivo = objetivo - sumaObligatoria;

        if (nuevoObjetivo < 0) return false;
        if (nuevoObjetivo == 0) return true;

        return buscarSuma(candidatos, 0, nuevoObjetivo);
    }

    static boolean buscarSuma(List<Integer> lista, int index, int objetivo) {
        if (objetivo == 0) return true;
        if (index == lista.size() || objetivo < 0) return false;

        // incluir o no incluir el número actual
        return buscarSuma(lista, index + 1, objetivo - lista.get(index)) ||
               buscarSuma(lista, index + 1, objetivo);
    }

    public static boolean evaluarEntrada(String entrada) {
        String[] partes = entrada.trim().split(" ");
        int n = Integer.parseInt(partes[0]);

        if (partes.length != n + 2) {
            System.out.println("true");
            return false;
        }

        List<Integer> numeros = new ArrayList<>();
        for (int i = 1; i <= n; i++) {
            numeros.add(Integer.parseInt(partes[i]));
        }

        int objetivo = Integer.parseInt(partes[n + 1]);
        return puedeFormarSuma(numeros, objetivo);
    }

    public static void main(String[] args) {
        String[] entradas = {
            "5 4 8 10 3 5 27",
            "5 4 8 10 3 6 27",
            "6 2 16 5 7 10 33",
            "6 2 16 5 3 10 33",
            "4 2 5 1 6 13"
        };

        for (String entrada : entradas) {
            System.out.println(evaluarEntrada(entrada));
        }
    }
}
