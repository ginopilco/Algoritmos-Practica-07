import javax.swing.*;
import java.awt.*;

public class PythagorasTree extends JPanel {
    private int profundidad;
    //niveles del arbol
    public PythagorasTree(int profundidad) {
        this.profundidad = profundidad;
        // papel donde se dibujara
        setPreferredSize(new Dimension(800, 800));
    }
    //DIBUJA 
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        // Fondo
        g2d.setColor(Color.BLACK);
        g2d.fillRect(0, 0, getWidth(), getHeight());

        // Primer color
        g2d.setColor(Color.GREEN);

        // Llamada inicial a la recursión
        trazaArbol(g2d, 350, 600, 100, -90, profundidad);
    }
    // funcion recursiva
    // x y comienzan 
    // lado tamańo cuadrado 
    private void trazaArbol(Graphics2D g, int x, int y, int lado, double angulo, int nivel) {
        if (nivel == 0 || lado < 2) return;

        int x2 = x + (int) (lado * Math.cos(Math.toRadians(angulo)));
        int y2 = y + (int) (lado * Math.sin(Math.toRadians(angulo)));

        g.drawLine(x, y, x2, y2);

        int nuevoLado = (int) (lado * 0.7);

        // Cambiar color para cada nivel
        float ratio = (float) nivel / profundidad;
        g.setColor(Color.getHSBColor(ratio * 0.4f, 1.0f, 1.0f));

        // Llamadas recursivas
        trazaArbol(g, x2, y2, nuevoLado, angulo - 45, nivel - 1); // Izquierda
        trazaArbol(g, x2, y2, nuevoLado, angulo + 45, nivel - 1); // Derecha
    }

    public static void main(String[] args) {
        // Cambia 6, 8 o 10 para probar distintos niveles
        JFrame frame = new JFrame("Árbol de Pitagoras");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new PythagorasTree(10)); 
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
