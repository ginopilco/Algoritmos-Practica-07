import java.util.Scanner;

public class RodCutting {

    // Método recursivo sin memorización (solución ingenua)
    static int naiveGetValue(int[] values, int length) {
        if (length <= 0)
            return 0;

        int tmpMax = -1;
        for (int i = 0; i < length; i++) {
            tmpMax = Math.max(tmpMax, values[i] + naiveGetValue(values, length - i - 1));
        }
        return tmpMax;
    }

    // Método utilizando Programación Dinámica (Bottom-Up)
    static int dpGetValue(int[] values, int rodLength) {
        int[] subSolutions = new int[rodLength + 1];

        for (int i = 1; i <= rodLength; i++) {
            int tmpMax = -1;
            for (int j = 0; j < i; j++) {
                tmpMax = Math.max(tmpMax, values[j] + subSolutions[i - j - 1]);
            }
            subSolutions[i] = tmpMax;
        }

        return subSolutions[rodLength];
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Definimos los valores para cada longitud de varilla
        int[] values = new int[]{3, 7, 1, 3, 9}; // Los precios de las piezas
        int rodLength = values.length;

        // Menú para seleccionar el enfoque
        System.out.println("Seleccione el enfoque para resolver el problema de corte de varilla:");
        System.out.println("1. Solución ingenua (sin programación dinámica)");
        System.out.println("2. Solución con programación dinámica");

        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                System.out.println("🔁 [Naive] El valor máximo es: " + naiveGetValue(values, rodLength));
                break;

            case 2:
                System.out.println("✅ [DP] El valor máximo es: " + dpGetValue(values, rodLength));
                break;

            default:
                System.out.println("Opción no válida.");
        }

        scanner.close();
    }
}
