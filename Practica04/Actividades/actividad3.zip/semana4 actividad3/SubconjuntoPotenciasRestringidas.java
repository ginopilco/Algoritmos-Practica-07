import java.util.*;

public class SubconjuntoPotenciasRestringidas {

    // Verifica si un número es potencia de 2
    static boolean esPotenciaDe2(int n) {
        return n > 0 && (n & (n - 1)) == 0;
    }

    // Verifica si se puede formar la suma objetivo con las restricciones dadas
    static boolean puedeFormarSuma(List<Integer> numeros, int objetivo) {
        List<Integer> obligatorios = new ArrayList<>();
        List<Integer> opcionales = new ArrayList<>();

        for (int i = 0; i < numeros.size(); i++) {
            int num = numeros.get(i);
            if (esPotenciaDe2(num)) {
                obligatorios.add(num);
            } else if (num % 5 == 0 && i + 1 < numeros.size() && numeros.get(i + 1) % 2 == 1) {
                // Excluir múltiplos de 5 seguidos por impar
                continue;
            } else {
                opcionales.add(num);
            }
        }

        int sumaObligatorios = obligatorios.stream().mapToInt(Integer::intValue).sum();
        int nuevoObjetivo = objetivo - sumaObligatorios;

        if (nuevoObjetivo < 0) return false;

        // Backtracking para buscar subconjunto que suma nuevoObjetivo
        return backtrack(opcionales, 0, 0, nuevoObjetivo);
    }

    static boolean backtrack(List<Integer> nums, int index, int sumaActual, int objetivo) {
        if (sumaActual == objetivo) return true;
        if (index == nums.size() || sumaActual > objetivo) return false;

        // Elegir o no elegir el número actual
        return backtrack(nums, index + 1, sumaActual + nums.get(index), objetivo)
            || backtrack(nums, index + 1, sumaActual, objetivo);
    }

    // Función para evaluar entradas como "5 4 8 10 3 5 27"
    public static boolean evaluarEntrada(String entrada) {
        String[] partes = entrada.trim().split(" ");
        int n = Integer.parseInt(partes[0]);
        List<Integer> numeros = new ArrayList<>();
        for (int i = 1; i <= n; i++) {
            numeros.add(Integer.parseInt(partes[i]));
        }
        int objetivo = Integer.parseInt(partes[n + 1]);
        return puedeFormarSuma(numeros, objetivo);
    }

    public static void main(String[] args) {
        String[] entradas = {
            "5 4 8 10 3 5 27",
            "5 4 8 10 3 6 27",
            "6 2 16 5 7 10 33",
            "6 2 16 5 3 10 33",
            "4 2 5 1 6 13"
        };

        for (String entrada : entradas) {
            System.out.println(evaluarEntrada(entrada));
        }
    }
}
