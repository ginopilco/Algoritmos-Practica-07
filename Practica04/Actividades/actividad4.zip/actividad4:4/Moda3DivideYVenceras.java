import java.util.ArrayList;
import java.util.Comparator;

class Limits {
    int[] a;
    int prim;
    int ult;

    public Limits(int[] array, int prim, int ult) {
        this.a = array;
        this.prim = prim;
        this.ult = ult;
    }

    public int length() {
        return ult - prim + 1;
    }
}

class SetVectors {
    private ArrayList<Limits> set;

    public SetVectors() {
        this.set = new ArrayList<>();
    }

    public void insertar(Limits p) {
        set.add(p);
    }

    public Limits mayor() {
        if (set.isEmpty()) return null;
        Limits max = set.stream().max(Comparator.comparingInt(Limits::length)).get();
        set.remove(max);
        return max;
    }

    public int longMayor() {
        if (set.isEmpty()) return 0;
        return set.stream().mapToInt(Limits::length).max().orElse(0);
    }

    public boolean esVacio() {
        return set.isEmpty();
    }

    public void destruir() {
        set.clear();
    }
}

public class Moda3DivideYVenceras {

    public static int[] pivote2(int[] a, int mediana, int prim, int ult) {
        int izq = prim;
        int der = ult + 1;
        int i = prim;

        while (i < der) {
            if (a[i] < mediana) {
                int temp = a[i];
                a[i] = a[izq];
                a[izq] = temp;
                izq++;
                i++;
            } else if (a[i] > mediana) {
                der--;
                int temp = a[i];
                a[i] = a[der];
                a[der] = temp;
            } else {
                i++;
            }
        }

        return new int[]{izq, der};
    }

    public static int moda3(int[] a, int prim, int ult) {
        SetVectors homogeneo = new SetVectors();
        SetVectors heterogeneo = new SetVectors();

        Limits p = new Limits(a, prim, ult);
        heterogeneo.insertar(p);

        while (heterogeneo.longMayor() > homogeneo.longMayor()) {
            p = heterogeneo.mayor();
            if (p == null) break;

            int mediana = a[(p.prim + p.ult) / 2];
            int[] pivote = pivote2(p.a, mediana, p.prim, p.ult);
            int izq = pivote[0];
            int der = pivote[1];

            Limits p1 = new Limits(p.a, p.prim, izq - 1);
            Limits p2 = new Limits(p.a, izq, der - 1);
            Limits p3 = new Limits(p.a, der, p.ult);

            if (p1.prim <= p1.ult) heterogeneo.insertar(p1);
            if (p3.prim <= p3.ult) heterogeneo.insertar(p3);
            if (p2.prim <= p2.ult) homogeneo.insertar(p2);
        }

        if (homogeneo.esVacio()) {
            return a[prim];
        }

        p = homogeneo.mayor();
        homogeneo.destruir();
        heterogeneo.destruir();
        return p.a[p.prim];
    }

    // === Ejemplo de uso ===
    public static void main(String[] args) {
        int[] arr = {1, 3, 2, 3, 3, 4, 5, 3, 6, 3};
        int resultado = moda3(arr, 0, arr.length - 1);
        System.out.println("Moda encontrada: " + resultado);
    }
}
